package cn.fancybull.business.livingpeople.repository;

import cn.fancybull.business.entity.FwResident;
import cn.fancybull.business.entity.FwResidentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FwResidentHistoryRepository extends JpaRepository<FwResidentHistory,String> {
    List<FwResidentHistory> findByHouseinfoid(String houseinfoid);
    List<FwResidentHistory> findBySystemid(String systemid);

}
