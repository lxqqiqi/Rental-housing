package cn.fancybull.business.livingpeople.service;

import cn.fancybull.business.entity.FwResident;
import cn.fancybull.business.livingpeople.repository.FwResidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FwResidentService {
    @Autowired
    private FwResidentRepository fwResidentRepository;

    public List<FwResident> findBySystemid(String systemid) {
        List<FwResident> fwResidentList = fwResidentRepository.findBySystemid(systemid);
        return fwResidentList;
    }

    public void save(FwResident fwResident) {
        fwResidentRepository.save(fwResident);
    }

    public void delete(FwResident fwResident) {
        fwResidentRepository.delete(fwResident);
    }
    public FwResident findByResidentid(String residentid){
        return fwResidentRepository.findByResidentid(residentid);
    }
}
