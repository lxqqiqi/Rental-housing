package cn.fancybull.business.housing.control;

import cn.fancybull.business.entity.*;
import cn.fancybull.business.housing.dto.FWHouseinfoDTO;
import cn.fancybull.business.housing.dto.FWHouseinfoMoreDTO;
import cn.fancybull.business.housing.dto.TestDTO;
import cn.fancybull.business.housing.dto.YwJbBzdzDTO;
import cn.fancybull.business.housing.service.FWHouseinfoHistoryService;
import cn.fancybull.business.housing.service.FwHouseinfoService;
import cn.fancybull.business.housing.service.YwJbBzdzService;
import cn.fancybull.business.livingpeople.service.FWResidentHistoryService;
import cn.fancybull.business.livingpeople.service.FwResidentService;
import cn.fancybull.business.user.service.FWUserService;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

//import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/fwhouseinfo")
@CrossOrigin
//@Slf4j
public class FwHouseinfoController {
    @Autowired
    private FwHouseinfoService fwHouseinfoService;
    @Autowired
    private FwResidentService fwResidentService;

    @Autowired
    private FWResidentHistoryService fwResidentHistoryService;

    @Autowired
    private FWHouseinfoHistoryService fwHouseinfoHistoryService;

    @Autowired
    private YwJbBzdzService ywJbBzdzService;

    @Autowired
    private FWUserService fwUserService;
    /**
     * 审核房屋
     */
    @RequestMapping("/audit")
    public JsonResult audit(@RequestBody FwHouseinfo fwHouseinfo) {
         String houseinfoid = fwHouseinfo.getHouseinfoid();
        FwHouseinfo fwHouseinfo1 = fwHouseinfoService.selectByHouseinfoid(houseinfoid);
        fwHouseinfo1.setIfverify(fwHouseinfo.getIfverify());//审核0未审核1审核不通过2审核通过
        fwHouseinfo1.setVerifytime(new Timestamp(System.currentTimeMillis()));
        fwHouseinfo1.setVerifyperson(fwHouseinfo.getVerifyperson());
        fwHouseinfo1.setVerifydesc(fwHouseinfo.getVerifydesc());
        fwHouseinfo1.setOrgid(fwHouseinfo.getOrgid());
        fwHouseinfo1.setRemark(fwHouseinfo.getRemark());
        JsonResult jsonResult=new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;

    }


    /**
     * 批量添加房屋
     */
    @RequestMapping("/edit")
    public JsonResult edit(@RequestBody FWHouseinfoMoreDTO fwHouseinfoMoreDTO) {
//        int a = fwHouseinfoMoreDTO.getSystemids().size();
        List<String> system = fwHouseinfoMoreDTO.getDzmcs();//获取标准地址数组
        int a = system.size();
        //增加积分
        if (fwHouseinfoMoreDTO.getHouseinfoid()==null) {
            FwUser fwUser = fwUserService.findByUSerid(fwHouseinfoMoreDTO.getUserid());
            String dqjf = fwUser.getDqjf();
            int nowdqjfs = Integer.parseInt(dqjf) + a * 5;
            String nowdqjf = String.valueOf(nowdqjfs);
            fwUser.setDqjf(nowdqjf);
            //当前等级判断
            if (nowdqjfs <= 100 && nowdqjfs >= 0) {
                if (fwUser.getPfdj().equals("0")) {

                } else {
                    fwUser.setPfdj("0");
                    fwUserService.save(fwUser);
                }
            } else if (nowdqjfs <= 200) {
                if (fwUser.getPfdj().equals("1")) {

                } else {
                    fwUser.setPfdj("1");
                    fwUserService.save(fwUser);

                }
            } else {
                if (fwUser.getPfdj().equals("2")) {

                } else {
                    fwUser.setPfdj("2");
                    fwUserService.save(fwUser);
                }
            }
        }


        for(int i=0;i<a;i++) {
            FwHouseinfo fwHouseinfo = new FwHouseinfo();

            if(fwHouseinfoMoreDTO.getHousedeclareid()==null) {
                Timestamp nowdate = new Timestamp(System.currentTimeMillis());
                fwHouseinfo.setHousedeclareid(nowdate.getTime());
            } else {
                fwHouseinfo.setHousedeclareid(fwHouseinfoMoreDTO.getHousedeclareid());
            }

            fwHouseinfo.setIdsyfw(fwHouseinfoMoreDTO.getIdsyfw());
            if(fwHouseinfoMoreDTO.getIfverify()!=null) {
                fwHouseinfo.setIfverify(fwHouseinfoMoreDTO.getIfverify());//0未审核1审核未通过2审核通过
            } else {
                fwHouseinfo.setIfverify("0");
            }
            fwHouseinfo.setIslast(fwHouseinfoMoreDTO.getIslast());
            fwHouseinfo.setLvczwbs(fwHouseinfoMoreDTO.getLvczwbs());
            if(fwHouseinfoMoreDTO.getLvfwcqxzzldm()==null) {
                fwHouseinfo.setLvfwcqxzzldm("私人");
            } else {
                fwHouseinfo.setLvfwcqxzzldm(fwHouseinfo.getLvfwcqxzzldm());
            }
            fwHouseinfo.setLvfwczjs(fwHouseinfoMoreDTO.getLvfwczjs());
            fwHouseinfo.setLvfwczmj(fwHouseinfoMoreDTO.getLvfwczmj());
            fwHouseinfo.setLvfwczyt(fwHouseinfoMoreDTO.getLvfwczyt());
            fwHouseinfo.setLvfwlbdm(fwHouseinfoMoreDTO.getLvfwlbdm());
            if(fwHouseinfoMoreDTO.getLvfwytdm()==null) {
                fwHouseinfo.setLvfwytdm("私宅");
            } else {
                fwHouseinfo.setLvfwytdm(fwHouseinfoMoreDTO.getLvfwytdm());
            }
            fwHouseinfo.setHouseinfoid(fwHouseinfoMoreDTO.getHouseinfoid());
            fwHouseinfo.setLvfzgmsfhm(fwHouseinfoMoreDTO.getLvfzgmsfhm());
            fwHouseinfo.setLvfzlxdh(fwHouseinfoMoreDTO.getLvfzlxdh());
            fwHouseinfo.setLvfzxm(fwHouseinfoMoreDTO.getLvfzxm());
            fwHouseinfo.setLvtgrgmsfhm(fwHouseinfoMoreDTO.getLvtgrgmsfhm());
            fwHouseinfo.setLvtgrlxdh(fwHouseinfoMoreDTO.getLvtgrlxdh());
            fwHouseinfo.setLvtgrxm(fwHouseinfoMoreDTO.getLvtgrxm());
            fwHouseinfo.setOrgid(fwHouseinfoMoreDTO.getOrgid());
            fwHouseinfo.setRemark(fwHouseinfoMoreDTO.getRemark());
            fwHouseinfo.setUserid(fwHouseinfoMoreDTO.getUserid());
            fwHouseinfo.setVerifydesc(fwHouseinfoMoreDTO.getVerifydesc());
            fwHouseinfo.setVerifyperson(fwHouseinfoMoreDTO.getVerifyperson());
            fwHouseinfo.setVerifytime(fwHouseinfoMoreDTO.getVerifytime());
            fwHouseinfo.setWtglygmsfhm(fwHouseinfoMoreDTO.getWtglygmsfhm());
            fwHouseinfo.setWtglylxdh(fwHouseinfoMoreDTO.getWtglylxdh());
            fwHouseinfo.setWtglyxm(fwHouseinfoMoreDTO.getWtglyxm());
            //地址换systemid
            YwJbBzdzDTO ywJbBzdzDTO = new YwJbBzdzDTO();
            ywJbBzdzDTO.setDzmc(fwHouseinfoMoreDTO.getDzmcs().get(i));

            String systemid = ywJbBzdzService.getsystemid(ywJbBzdzDTO).get(0).getDzmc();
            fwHouseinfo.setSystemid(systemid);
            fwHouseinfoService.save(fwHouseinfo);
            fwHouseinfoService.flush();
        }
//

        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("OK");
        return jsonResult;
    }

    @RequestMapping("/test")
    public JsonResult<TestDTO> test() {
        JsonResult<TestDTO> testDTOJsonResult= new JsonResult<TestDTO>();
        TestDTO testDTO = new TestDTO();
        testDTO.setTestid("2");
        testDTO.setUsername("lxq");
        List<String> list = new ArrayList<>();
        list.add("ddd");
        list.add("ttt");
        testDTO.setListTest(list);
        testDTOJsonResult.setCode("200");
        testDTOJsonResult.setMsg("请求成功");
        testDTOJsonResult.setData(testDTO);
        return testDTOJsonResult;
    }


    /**
     * 查询我的房屋
     */
    @RequestMapping("/index")
    public JsonResult<List<FWHouseinfoDTO>> index(String userid) {
        List<FWHouseinfoDTO> fwHouseinfoDTOList = new ArrayList<FWHouseinfoDTO>();
        List<FwHouseinfo> fwHouseinfoList = fwHouseinfoService.selectFWHouse(userid);
        for(int i=0;i<fwHouseinfoList.size();i++) {
            List<FwResident> fwResidents = fwResidentService.findBySystemid(fwHouseinfoList.get(i).getSystemid());
            int now = fwResidents.size();

            List<FwResidentHistory> fwResidentHistories = fwResidentHistoryService.findBySystemid(fwHouseinfoList.get(i).getSystemid());
            int total = fwResidentHistories.size();

            FWHouseinfoDTO fwHouseinfoDTO = new FWHouseinfoDTO();
            fwHouseinfoDTO.setNowPeople(now);
//            int tatals = now + total;
            fwHouseinfoDTO.setTotalPeople(total);
            fwHouseinfoDTO.setLvfwczjs(fwHouseinfoList.get(i).getLvfwczjs());
            String systemid = fwHouseinfoList.get(i).getSystemid();
            fwHouseinfoDTO.setSystemid(fwHouseinfoList.get(i).getSystemid());
            //获取标准地址
            YwJbBzdzDTO ywJbBzdzDTO = new YwJbBzdzDTO();
            ywJbBzdzDTO.setSystemid(fwHouseinfoList.get(i).getSystemid());
            List<YwJbBzdzDTO> list =ywJbBzdzService.findBysystemid(ywJbBzdzDTO);
//            List<YwJbBzdz> ywJbBzdz = ywJbBzdzService.findBySystemid(fwHouseinfoList.get(i).getSystemid());
//            fwHouseinfoDTO.setDzmc(ywJbBzdz.get(0).getDzmc());
            String dzmc = list.get(0).getDzmc();
            fwHouseinfoDTO.setDzmc(list.get(0).getDzmc());
            fwHouseinfoDTOList.add(fwHouseinfoDTO);
        }
        JsonResult<List<FWHouseinfoDTO>> jsonResult;
        jsonResult = new JsonResult<List<FWHouseinfoDTO>>();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        jsonResult.setData(fwHouseinfoDTOList);
        return jsonResult;
    }

    @RequestMapping("/delete")
    public JsonResult delete(@RequestBody FwHouseinfo fwHouseinfo) {
        FwHouseinfo fwHouseinfo1 = fwHouseinfoService.findByHouseinfoid(fwHouseinfo.getHouseinfoid());
        FwHouseinfoHistory fwHouseinfoHistory = new FwHouseinfoHistory();
        fwHouseinfoHistory.setHousedeclareid(fwHouseinfo1.getHousedeclareid());
        fwHouseinfoHistory.setIdsyfw(fwHouseinfo1.getIdsyfw());
        fwHouseinfoHistory.setIfverify(fwHouseinfo1.getIfverify());
        fwHouseinfoHistory.setIslast(fwHouseinfo1.getIslast());
        fwHouseinfoHistory.setLvczwbs(fwHouseinfo1.getLvczwbs());
        fwHouseinfoHistory.setLvfwcqxzzldm(fwHouseinfo1.getLvfwcqxzzldm());
        fwHouseinfoHistory.setLvfwczjs(fwHouseinfo1.getLvfwczjs());
        fwHouseinfoHistory.setLvfwczmj(fwHouseinfo1.getLvfwczmj());
        fwHouseinfoHistory.setLvfwczyt(fwHouseinfo1.getLvfwczyt());
        fwHouseinfoHistory.setLvfwlbdm(fwHouseinfo1.getLvfwlbdm());
        fwHouseinfoHistory.setLvfwytdm(fwHouseinfo1.getLvfwytdm());
        fwHouseinfoHistory.setLvfzgmsfhm(fwHouseinfo1.getLvfzgmsfhm());
        fwHouseinfoHistory.setLvfzlxdh(fwHouseinfo1.getLvfzlxdh());
        fwHouseinfoHistory.setLvfzxm(fwHouseinfo1.getLvfzxm());
        fwHouseinfoHistory.setLvtgrgmsfhm(fwHouseinfo1.getLvtgrgmsfhm());
        fwHouseinfoHistory.setLvtgrlxdh(fwHouseinfo1.getLvtgrlxdh());
        fwHouseinfoHistory.setLvtgrxm(fwHouseinfo1.getLvtgrxm());
        fwHouseinfoHistory.setOrgid(fwHouseinfo1.getOrgid());
        fwHouseinfoHistory.setRemark(fwHouseinfo1.getRemark());
        fwHouseinfoHistory.setSystemid(fwHouseinfo1.getSystemid());
        fwHouseinfoHistory.setUserid(fwHouseinfo1.getUserid());
        fwHouseinfoHistory.setVerifydesc(fwHouseinfo1.getVerifydesc());
        fwHouseinfoHistory.setVerifyperson(fwHouseinfo1.getVerifyperson());
        fwHouseinfoHistory.setVerifytime(fwHouseinfo1.getVerifytime());
        fwHouseinfoHistory.setWtglygmsfhm(fwHouseinfo1.getWtglygmsfhm());
        fwHouseinfoHistory.setWtglylxdh(fwHouseinfo1.getWtglylxdh());
        fwHouseinfoHistory.setWtglyxm(fwHouseinfo1.getWtglyxm());
        fwHouseinfoService.delete(fwHouseinfo);
        fwHouseinfoHistoryService.save(fwHouseinfoHistory);
        JsonResult jsonResult;
        jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;
    }
}
