package cn.fancybull.business.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "fw_feedback", schema = "crebas", catalog = "")
public class FwFeedback {
    private String feedbackid;
    private String fknr;
    private String fktp;
    private String userid;
    private Timestamp fksj;

    @Id
    @Column(name = "feedbackid")
    @GenericGenerator(name = "systemUUID", strategy = "uuid")
    @GeneratedValue(generator = "systemUUID")
    public String getFeedbackid() {
        return feedbackid;
    }

    public void setFeedbackid(String feedbackid) {
        this.feedbackid = feedbackid;
    }

    @Basic
    @Column(name = "fknr")
    public String getFknr() {
        return fknr;
    }

    public void setFknr(String fknr) {
        this.fknr = fknr;
    }

    @Basic
    @Column(name = "fktp")
    public String getFktp() {
        return fktp;
    }

    public void setFktp(String fktp) {
        this.fktp = fktp;
    }

    @Basic
    @Column(name = "userid")
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Basic
    @Column(name = "fksj")
    public Timestamp getFksj() {
        return fksj;
    }

    public void setFksj(Timestamp fksj) {
        this.fksj = fksj;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FwFeedback that = (FwFeedback) o;
        return Objects.equals(feedbackid, that.feedbackid) &&
                Objects.equals(fknr, that.fknr) &&
                Objects.equals(fktp, that.fktp) &&
                Objects.equals(userid, that.userid) &&
                Objects.equals(fksj, that.fksj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(feedbackid, fknr, fktp, userid, fksj);
    }
}
