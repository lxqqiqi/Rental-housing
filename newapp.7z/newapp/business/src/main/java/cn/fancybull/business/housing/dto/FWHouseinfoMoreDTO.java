package cn.fancybull.business.housing.dto;

import cn.fancybull.business.entity.FwHouseinfo;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class FWHouseinfoMoreDTO extends FwHouseinfo {
    private String houseinfoid;
    private String userid;
    private String islast;
    private Long idsyfw;
    private String lvfwlbdm;
    private String lvfwytdm;
    private String lvfwcqxzzldm;
    private String lvczwbs;
    private String lvfwczyt;
    private BigDecimal lvfwczmj;
    private Integer lvfwczjs;
    private String lvfzxm;
    private String lvfzgmsfhm;
    private String lvfzlxdh;
    private String lvtgrxm;
    private String lvtgrgmsfhm;
    private String lvtgrlxdh;
    private String wtglyxm;
    private String wtglygmsfhm;
    private String wtglylxdh;
    private String ifverify;
    private Timestamp verifytime;
    private String verifyperson;
    private String verifydesc;
    private String orgid;
    private String remark;

    @Override
    public String getHouseinfoid() {
        return houseinfoid;
    }

    @Override
    public void setHouseinfoid(String houseinfoid) {
        this.houseinfoid = houseinfoid;
    }

    @Override
    public String getUserid() {
        return userid;
    }

    @Override
    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public String getIslast() {
        return islast;
    }

    @Override
    public void setIslast(String islast) {
        this.islast = islast;
    }

    @Override
    public Long getIdsyfw() {
        return idsyfw;
    }

    @Override
    public void setIdsyfw(Long idsyfw) {
        this.idsyfw = idsyfw;
    }

    @Override
    public String getLvfwlbdm() {
        return lvfwlbdm;
    }

    @Override
    public void setLvfwlbdm(String lvfwlbdm) {
        this.lvfwlbdm = lvfwlbdm;
    }

    @Override
    public String getLvfwytdm() {
        return lvfwytdm;
    }

    @Override
    public void setLvfwytdm(String lvfwytdm) {
        this.lvfwytdm = lvfwytdm;
    }

    @Override
    public String getLvfwcqxzzldm() {
        return lvfwcqxzzldm;
    }

    @Override
    public void setLvfwcqxzzldm(String lvfwcqxzzldm) {
        this.lvfwcqxzzldm = lvfwcqxzzldm;
    }

    @Override
    public String getLvczwbs() {
        return lvczwbs;
    }

    @Override
    public void setLvczwbs(String lvczwbs) {
        this.lvczwbs = lvczwbs;
    }

    @Override
    public String getLvfwczyt() {
        return lvfwczyt;
    }

    @Override
    public void setLvfwczyt(String lvfwczyt) {
        this.lvfwczyt = lvfwczyt;
    }

    @Override
    public BigDecimal getLvfwczmj() {
        return lvfwczmj;
    }

    @Override
    public void setLvfwczmj(BigDecimal lvfwczmj) {
        this.lvfwczmj = lvfwczmj;
    }

    @Override
    public Integer getLvfwczjs() {
        return lvfwczjs;
    }

    @Override
    public void setLvfwczjs(Integer lvfwczjs) {
        this.lvfwczjs = lvfwczjs;
    }

    @Override
    public String getLvfzxm() {
        return lvfzxm;
    }

    @Override
    public void setLvfzxm(String lvfzxm) {
        this.lvfzxm = lvfzxm;
    }

    @Override
    public String getLvfzgmsfhm() {
        return lvfzgmsfhm;
    }

    @Override
    public void setLvfzgmsfhm(String lvfzgmsfhm) {
        this.lvfzgmsfhm = lvfzgmsfhm;
    }

    @Override
    public String getLvfzlxdh() {
        return lvfzlxdh;
    }

    @Override
    public void setLvfzlxdh(String lvfzlxdh) {
        this.lvfzlxdh = lvfzlxdh;
    }

    @Override
    public String getLvtgrxm() {
        return lvtgrxm;
    }

    @Override
    public void setLvtgrxm(String lvtgrxm) {
        this.lvtgrxm = lvtgrxm;
    }

    @Override
    public String getLvtgrgmsfhm() {
        return lvtgrgmsfhm;
    }

    @Override
    public void setLvtgrgmsfhm(String lvtgrgmsfhm) {
        this.lvtgrgmsfhm = lvtgrgmsfhm;
    }

    @Override
    public String getLvtgrlxdh() {
        return lvtgrlxdh;
    }

    @Override
    public void setLvtgrlxdh(String lvtgrlxdh) {
        this.lvtgrlxdh = lvtgrlxdh;
    }

    @Override
    public String getWtglyxm() {
        return wtglyxm;
    }

    @Override
    public void setWtglyxm(String wtglyxm) {
        this.wtglyxm = wtglyxm;
    }

    @Override
    public String getWtglygmsfhm() {
        return wtglygmsfhm;
    }

    @Override
    public void setWtglygmsfhm(String wtglygmsfhm) {
        this.wtglygmsfhm = wtglygmsfhm;
    }

    @Override
    public String getWtglylxdh() {
        return wtglylxdh;
    }

    @Override
    public void setWtglylxdh(String wtglylxdh) {
        this.wtglylxdh = wtglylxdh;
    }

    @Override
    public String getIfverify() {
        return ifverify;
    }

    @Override
    public void setIfverify(String ifverify) {
        this.ifverify = ifverify;
    }

    @Override
    public Timestamp getVerifytime() {
        return verifytime;
    }

    @Override
    public void setVerifytime(Timestamp verifytime) {
        this.verifytime = verifytime;
    }

    @Override
    public String getVerifyperson() {
        return verifyperson;
    }

    @Override
    public void setVerifyperson(String verifyperson) {
        this.verifyperson = verifyperson;
    }

    @Override
    public String getVerifydesc() {
        return verifydesc;
    }

    @Override
    public void setVerifydesc(String verifydesc) {
        this.verifydesc = verifydesc;
    }

    @Override
    public String getOrgid() {
        return orgid;
    }

    @Override
    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    @Override
    public String getRemark() {
        return remark;
    }

    @Override
    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<String> getSystemids() {
        return systemids;
    }

    public void setSystemids(List<String> systemids) {
        this.systemids = systemids;
    }

    public List<String> getDzmcs() {
        return dzmcs;
    }

    public void setDzmcs(List<String> dzmcs) {
        this.dzmcs = dzmcs;
    }

    private List<String> systemids;
    private List<String> dzmcs;//地址
}
