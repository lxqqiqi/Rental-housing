package cn.fancybull.business.user.repository;

import cn.fancybull.business.entity.FwMessage;
import cn.fancybull.business.test.dto.UserDTO;
import cn.fancybull.business.user.dto.FWMessageDTO;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class FWMessageDAO {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
//    public List<FWMessageDTO> getMessageList(String userid) {
//        StringBuffer sb = new StringBuffer();
//        sb.append("select fw_message.messageid,fw_message.eventid,fw_message.ifread,fw_message.messagetime,fw_message.messagetype,fw_message.readtime,fw_message.title,fw_message.userid,fw_messagedetail.columnname,fw_messagedetail.columnvalue,fw_messagedetail.messagedetailid ");
//        sb.append(" from fw_message ");
//        sb.append(" inner join fw_messagedetail on fw_messagedetail.messageid=fw_message.messageid ");
//        sb.append(" where fw_message.userid=:userid ");
//        FWMessageDTO param = new FWMessageDTO();
//        param.setUserid(userid);
//        List<FWMessageDTO> fwMessageDTOList = commonRepository.queryBySql(sb.toString(),param,FWMessageDTO.class);
////        redis.putValue("abc", "123");
//        logger.info("测试日志输出Message");
//        return fwMessageDTOList;
//    }
}
