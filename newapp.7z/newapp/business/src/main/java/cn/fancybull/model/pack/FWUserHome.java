package cn.fancybull.model.pack;

public class FWUserHome {
    private String pfdj;
    private String dqjf;
    private String sm;//实名
    private String userid;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPfdj() {
        return pfdj;
    }

    public void setPfdj(String pfdj) {
        this.pfdj = pfdj;
    }

    public String getDqjf() {
        return dqjf;
    }

    public void setDqjf(String dqjf) {
        this.dqjf = dqjf;
    }

    public String getSm() {
        return sm;
    }

    public void setSm(String sm) {
        this.sm = sm;
    }
}
