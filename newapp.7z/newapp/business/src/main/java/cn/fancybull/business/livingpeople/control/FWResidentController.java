package cn.fancybull.business.livingpeople.control;

import cn.fancybull.business.entity.FwResident;
import cn.fancybull.business.entity.FwResidentHistory;
import cn.fancybull.business.entity.FwUser;
import cn.fancybull.business.livingpeople.dto.YwJbSyrkjbxxDTO;
import cn.fancybull.business.livingpeople.service.FWResidentHistoryService;
import cn.fancybull.business.livingpeople.service.FwResidentService;
import cn.fancybull.business.livingpeople.service.YwJbSyrkjbxxService;
import cn.fancybull.business.user.service.FWUserService;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.List;

@RestController
@RequestMapping("/fwresident")
@CrossOrigin
public class FWResidentController {
    @Autowired
    private FwResidentService fwResidentService;

    @Autowired
    private FWResidentHistoryService fwResidentHistoryService;

    @Autowired
    private YwJbSyrkjbxxService ywJbSyrkjbxxService;

    @Autowired
    private FWUserService fwUserService;

    @RequestMapping("/index")
    public JsonResult<List<FwResident>> index(String systemid) {
        JsonResult<List<FwResident>> jsonResult = new JsonResult<List<FwResident>>();
        List<FwResident> fwResidentList = fwResidentService.findBySystemid(systemid);
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        jsonResult.setData(fwResidentList);
        return jsonResult;
    }

    @RequestMapping("/edit")
    public JsonResult edit(FwResident fwResident,String userid) {
//积分
//        System.out.println(userid);
        FwUser fwUser = fwUserService.findByUSerid(userid);
        if(fwResident.getResidentid()==null) {
            String dqjf = fwUser.getDqjf();
            int nowdqjfs = Integer.parseInt(dqjf) + 2;
            String nowdqjf = String.valueOf(nowdqjfs);
            fwUser.setDqjf(nowdqjf);
            //当前等级判断
            if(nowdqjfs<=100&&nowdqjfs>=0) {
                if(fwUser.getPfdj().equals("0")) {

                } else {
                    fwUser.setPfdj("0");
                    fwUserService.save(fwUser);
                }
            } else if(nowdqjfs<=200) {
                if(fwUser.getPfdj().equals("1")) {

                } else {
                    fwUser.setPfdj("1");
                    fwUserService.save(fwUser);

                }
            } else {
                if(fwUser.getPfdj().equals("2")) {

                } else {
                    fwUser.setPfdj("2");
                    fwUserService.save(fwUser);
                }
            }
        }



        if(fwResident.getDjsj()==null) {
            Timestamp nowdate = new Timestamp(System.currentTimeMillis());
            fwResident.setDjsj(nowdate);
        }
        YwJbSyrkjbxxDTO ywJbSyrkjbxxDTO = new YwJbSyrkjbxxDTO();
        ywJbSyrkjbxxDTO.setSfzhm(fwResident.getLvzjhm());

        List<YwJbSyrkjbxxDTO> list =ywJbSyrkjbxxService.selectidsyrk(ywJbSyrkjbxxDTO);
        if(list.size()==1) {
                fwResident.setIdsyrk(Long.parseLong(list.get(0).getIdsyrk()));
        }
        fwResident.setLvzjzl("10");
        fwResident.setLvgjhdqdm("chn");

        JsonResult jsonResult = new JsonResult();
        fwResidentService.save(fwResident);
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;
    }

    @RequestMapping("/delete")
    public JsonResult delete(FwResident fwResident,String userid) {
        FwResident fwResident1 = fwResidentService.findByResidentid(fwResident.getResidentid());
        fwResidentService.delete(fwResident);
        FwResidentHistory fwResidentHistory = new FwResidentHistory();
        fwResidentHistory.setCheckindate(fwResident1.getCheckindate());
        fwResidentHistory.setDjsj(fwResident1.getDjsj());
        fwResidentHistory.setHjdz(fwResident1.getHjdz());
        fwResidentHistory.setHouseinfoid(fwResident1.getHouseinfoid());
        fwResidentHistory.setIdsyfw(fwResident1.getIdsyfw());
        fwResidentHistory.setIdsyrk(fwResident1.getIdsyrk());
        fwResidentHistory.setLeavedate(fwResident.getLeavedate());
        fwResidentHistory.setLvcsrq(fwResident1.getLvcsrq());
        fwResidentHistory.setLvgjhdqdm(fwResident1.getLvgjhdqdm());
        fwResidentHistory.setLvlxdh(fwResident1.getLvlxdh());
        fwResidentHistory.setLvrylx(fwResident1.getLvrylx());
        fwResidentHistory.setLvxbdm(fwResident1.getLvxbdm());
        fwResidentHistory.setLvxm(fwResident1.getLvxm());
        fwResidentHistory.setLvywm(fwResident1.getLvywm());
        fwResidentHistory.setLvywx(fwResident1.getLvywx());
        fwResidentHistory.setLvzjhm(fwResident1.getLvzjhm());
        fwResidentHistory.setLvzjzl(fwResident1.getLvzjzl());
        fwResidentHistory.setResidenthistoryid(fwResident1.getHjdz());
        fwResidentHistory.setSystemid(fwResident1.getSystemid());
        fwResidentHistoryService.sava(fwResidentHistory);

        //积分
//        System.out.println(userid);
        FwUser fwUser = fwUserService.findByUSerid(userid);
        if(fwResident.getResidentid()==null) {
            String dqjf = fwUser.getDqjf();
            int nowdqjfs = Integer.parseInt(dqjf) + 1;
            String nowdqjf = String.valueOf(nowdqjfs);
            fwUser.setDqjf(nowdqjf);
            //当前等级判断
            if(nowdqjfs<=100&&nowdqjfs>=0) {
                if(fwUser.getPfdj().equals("0")) {

                } else {
                    fwUser.setPfdj("0");
                    fwUserService.save(fwUser);
                }
            } else if(nowdqjfs<=200) {
                if(fwUser.getPfdj().equals("1")) {

                } else {
                    fwUser.setPfdj("1");
                    fwUserService.save(fwUser);

                }
            } else {
                if(fwUser.getPfdj().equals("2")) {

                } else {
                    fwUser.setPfdj("2");
                    fwUserService.save(fwUser);
                }
            }
        }



        JsonResult jsonResult;
        jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;
    }

}
