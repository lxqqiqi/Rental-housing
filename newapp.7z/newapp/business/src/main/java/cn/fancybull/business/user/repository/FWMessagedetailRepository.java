package cn.fancybull.business.user.repository;

import cn.fancybull.business.entity.FwMessagedetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FWMessagedetailRepository extends JpaRepository<FwMessagedetail,String> {
    List<FwMessagedetail> findByMessageid(long messageid);
}
