package cn.fancybull.business.housing.service;

import cn.fancybull.business.entity.FwHouseinfoHistory;
import cn.fancybull.business.housing.repository.FWHouseinfoHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FWHouseinfoHistoryService {
    @Autowired
    private FWHouseinfoHistoryRepository fwHouseinfoHistoryRepository;

    public void delete(FwHouseinfoHistory fwHouseinfoHistory) {
        fwHouseinfoHistoryRepository.delete(fwHouseinfoHistory);
    }

    public void save(FwHouseinfoHistory fwHouseinfoHistory) {
        fwHouseinfoHistoryRepository.save(fwHouseinfoHistory);
    }
}
