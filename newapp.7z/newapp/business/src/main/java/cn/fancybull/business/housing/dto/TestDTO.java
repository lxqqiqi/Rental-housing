package cn.fancybull.business.housing.dto;

import java.util.List;

public class TestDTO {
    private String testid;
    private String username;

    public String getTestid() {
        return testid;
    }

    public void setTestid(String testid) {
        this.testid = testid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<String> getListTest() {
        return listTest;
    }

    public void setListTest(List<String> listTest) {
        this.listTest = listTest;
    }

    private List<String> listTest;
}
