package cn.fancybull.business.housing.dto;

public class YwJbBzdzDTO {
    private String systemid;

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid;
    }

    private String dzmc;//地址

    public String getDzmc() {
        return dzmc;
    }

    public void setDzmc(String dzmc) {
        this.dzmc = dzmc;
    }
}
