package cn.fancybull.business.livingpeople.service;

import cn.fancybull.business.entity.FwResidentHistory;
import cn.fancybull.business.livingpeople.repository.FwResidentHistoryRepository;
import cn.fancybull.business.livingpeople.repository.FwResidentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FWResidentHistoryService {
    @Autowired
    private FwResidentHistoryRepository fwResidentHistoryRepository;

    public void sava(FwResidentHistory fwResidentHistory) {
        fwResidentHistoryRepository.save(fwResidentHistory);
    }
    public List<FwResidentHistory> findBySystemid(String systemid) {
       return fwResidentHistoryRepository.findBySystemid(systemid);
    }
}
