package cn.fancybull.business.livingpeople.repository;

import cn.fancybull.business.entity.FwResident;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FwResidentRepository extends JpaRepository<FwResident,String> {
    List<FwResident> findBySystemid(String systemid);
    FwResident findByResidentid(String residentid);
}
