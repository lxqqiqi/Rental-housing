package cn.fancybull.business.audit.dto;

import java.util.List;

public class AuditFwhouseinfoDTO {
    private String houseinfoid;//出租屋基本信息id

    public String getHouseinfoid() {
        return houseinfoid;
    }

    public void setHouseinfoid(String houseinfoid) {
        this.houseinfoid = houseinfoid;
    }

    public List<String> getAudituserids() {
        return audituserids;
    }

    public void setAudituserids(List<String> audituserids) {
        this.audituserids = audituserids;
    }

    private List<String> audituserids;//审核人id
}
