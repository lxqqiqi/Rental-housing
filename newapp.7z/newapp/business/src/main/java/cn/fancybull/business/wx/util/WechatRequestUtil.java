package cn.fancybull.business.wx.util;

import java.util.HashMap;
import java.util.Map;

import cn.fancybull.business.user.util.HttpUtils;
import cn.fancybull.business.wx.cache.WechatRedisUtil;
import cn.fancybull.business.wx.emun.WxConst;
import cn.fancybull.business.wx.emun.WxLoginRedisKey;
import cn.fancybull.framework.utils.StringUtil;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONObject;

public class WechatRequestUtil {

    /**
     * 获取微信的openid
     *
     * @param code
     * @return
     */
    public static JSONObject getWxOpenid(String code) {
        try {
            String res = null;
            Map<String, String> headers = new HashMap<String, String>();
            Map<String, String> querys = new HashMap<String, String>();
            Map<String, String> bodys = new HashMap<String, String>();
            bodys.put("appid", WxConst.appid);
            bodys.put("secret", WxConst.App_Secret);
            bodys.put("js_code", code);
            bodys.put("grant_type", "authorization_code");
            HttpResponse response = HttpUtils.doGet("https://api.weixin.qq.com/sns/jscode2session?appid=" + bodys.get("appid") + "&secret=" + bodys.get("secret") + "&js_code=" + code + "&grant_type=authorization_code", null, "GET", headers, querys);

            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                res = EntityUtils.toString(response.getEntity());
                if (!StringUtil.isEmpty(res)) {
                    JSONObject json = JSONObject.parseObject(res);
                    return json;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }

    }

    public static String getAccessToken() {
        try {
            String access_token = (String) WechatRedisUtil.getValue(WxLoginRedisKey.wx_access_token);
            if(!StringUtil.isEmpty(access_token)){
                return access_token;
            }
            String res = null;
            HttpResponse response = HttpUtils.doGet("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + WxConst.appid + "&secret=" + WxConst.App_Secret, null, "GET", null, null);

            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                res = EntityUtils.toString(response.getEntity());
                if (!StringUtil.isEmpty(res)) {
                    JSONObject json = JSONObject.parseObject(res);
                    Object at = json.get("access_token");
                    if (null != at) {
                        access_token = at.toString();


                        // 从微信服务获取到的access_token有效时间为120分钟
                        WechatRedisUtil.putValue(WxLoginRedisKey.wx_access_token, access_token);
                        WechatRedisUtil.expire(WxLoginRedisKey.wx_access_token, 6000);// 有效时间100分钟
                        return access_token;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static JSONObject getUserInfo(String openid) {
        try {
            String access_token = getAccessToken();
            String res = null;
            HttpResponse response = HttpUtils.doGet("https://api.weixin.qq.com/cgi-bin/user/info?access_token=" + access_token + "&openid=" + openid + "&lang=zh_CN", null, "GET", null, null);

            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                res = EntityUtils.toString(response.getEntity());
                if (!StringUtil.isEmpty(res)) {
                    JSONObject json = JSONObject.parseObject(res);
                    return json;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public static JSONObject getAccecctoken() {
        try {
            HttpResponse response = HttpUtils.doGet("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + WxConst.appid + "&secret=" + WxConst.App_Secret, null, "GET", null, null);
            StatusLine statusLine = response.getStatusLine();
            String res = null;
            if (statusLine.getStatusCode() == 200) {
                res = EntityUtils.toString(response.getEntity());
                if (!StringUtil.isEmpty(res)) {
                    JSONObject json = JSONObject.parseObject(res);
                    return json;
                }
            }
            return null;


        } catch (Exception e) {
            return null;
        }
    }
}
