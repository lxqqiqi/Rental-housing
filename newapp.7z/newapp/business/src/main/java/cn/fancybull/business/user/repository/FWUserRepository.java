package cn.fancybull.business.user.repository;

import cn.fancybull.business.entity.FwUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FWUserRepository extends JpaRepository<FwUser,String> {
    List<FwUser> findByOpenid(String openid);
    FwUser findByUserid(String userid);
}
