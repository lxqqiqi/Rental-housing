package cn.fancybull.business.housing.repository;

import cn.fancybull.business.entity.FwHouseinfoHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FWHouseinfoHistoryRepository extends JpaRepository<FwHouseinfoHistory,String> {
}
