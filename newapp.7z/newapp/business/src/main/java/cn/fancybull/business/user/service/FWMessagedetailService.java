package cn.fancybull.business.user.service;

import cn.fancybull.business.entity.FwMessagedetail;
import cn.fancybull.business.user.repository.FWMessagedetailRepository;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.List;

@Service
public class FWMessagedetailService {
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    @Resource
    private FWMessagedetailRepository fwMessagedetailRepository;

    @Transactional
    public List<FwMessagedetail> selectByMessageid(long messageid) {
        return fwMessagedetailRepository.findByMessageid(messageid);
    }
}
