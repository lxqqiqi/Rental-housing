package cn.fancybull.business.img.control;

import cn.fancybull.business.entity.FwImg;
import cn.fancybull.business.img.service.FWImgService;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;

@RestController
@CrossOrigin
@RequestMapping("/fwimg")
public class FWImgController {

    @Autowired
    private FWImgService fwImgService;

    @RequestMapping("/edit")
    public JsonResult edit(FwImg fwImg) {
        Timestamp nowdate = new Timestamp(System.currentTimeMillis());
        fwImg.setScsj(nowdate);
        fwImgService.save(fwImg);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;
    }
}
