package cn.fancybull.business.user.control;

import cn.fancybull.business.entity.FwFeedback;
import cn.fancybull.business.entity.FwUser;
import cn.fancybull.business.user.service.FWFeedbackService;
import cn.fancybull.business.user.service.FWUserService;
import cn.fancybull.business.user.util.Base64Test;
import cn.fancybull.business.wx.util.Base64Util;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sun.misc.BASE64Decoder;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.List;

@RequestMapping("/fwfeddback")
@CrossOrigin
@RestController
public class FWFeedbackController {
    @Autowired
    private FWFeedbackService fwFeedbackService;

    @Autowired
    private FWUserService fwUserService;

    @RequestMapping("/index")
    public JsonResult<List<FwFeedback>> index(@RequestBody FwFeedback fwFeedback) {
        List<FwFeedback> fwFeedbacks =  fwFeedbackService.findByUserid(fwFeedback.getUserid());
        JsonResult<List<FwFeedback>> fwFeedbackJsonResult = new JsonResult<List<FwFeedback>>();
        fwFeedbackJsonResult.setCode("200");
        fwFeedbackJsonResult.setMsg("请求成功");
        fwFeedbackJsonResult.setData(fwFeedbacks);
        return fwFeedbackJsonResult;
    }


    @RequestMapping("/edit")
    public JsonResult edit(@RequestBody FwFeedback fwFeedback1) {
//    public JsonResult edit(String fknr,String fktp,String userid) {
        List<FwFeedback> list = fwFeedbackService.findByUserid(fwFeedback1.getUserid());
        //积分
        if(list.size()<4) {
            if(fwFeedback1.getFeedbackid()==null) {
                FwUser fwUser = fwUserService.findByUSerid(fwFeedback1.getUserid());
                String dqjf = fwUser.getDqjf();
                int nowdqjfs = Integer.parseInt(dqjf) + 5;
                String nowdqjf = String.valueOf(nowdqjfs);
                fwUser.setDqjf(nowdqjf);
                //当前等级判断
                if(nowdqjfs<=100&&nowdqjfs>=0) {
                    if(fwUser.getPfdj().equals("0")) {

                    } else {
                        fwUser.setPfdj("0");
                        fwUserService.save(fwUser);
                    }
                } else if(nowdqjfs<=200) {
                    if(fwUser.getPfdj().equals("1")) {

                    } else {
                        fwUser.setPfdj("1");
                        fwUserService.save(fwUser);

                    }
                } else {
                    if(fwUser.getPfdj().equals("2")) {

                    } else {
                        fwUser.setPfdj("2");
                        fwUserService.save(fwUser);
                    }
                }
            }

        }

        Timestamp nowdate = new Timestamp(System.currentTimeMillis());
        FwFeedback fwFeedback = new FwFeedback();
        fwFeedback.setFksj(nowdate);
        fwFeedback.setFknr(fwFeedback1.getFknr());
        fwFeedback.setUserid(fwFeedback1.getUserid());

        if(fwFeedback1.getFktp()!=null) {
            String url = "F:/Img2/" + fwFeedback1.getUserid() + System.currentTimeMillis() + ".jpg";

            Base64Util.generateImage(fwFeedback1.getFktp(), url);

            fwFeedback.setFktp(url);
        }
        fwFeedbackService.sava(fwFeedback);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");


        return jsonResult;
    }
}
