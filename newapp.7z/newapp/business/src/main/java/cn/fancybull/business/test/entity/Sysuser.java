package cn.fancybull.business.test.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * Sysuser entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "sysuser")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Sysuser implements java.io.Serializable {

	// Fields

	private String userid;
	private String username;
	private String passwd;
	private String description;
	private Date createtime;
	private Date lastlogontime;
	private Date lastlogofftime;
	private String lockstate;
	private Date locktime;
	private String lockreason;
	private String orgid;
	private String userkind;
	private String sfzhm;
	private String realname;
	private String xb;
	private String tel;
	private Date updatetime;
	private String oldpwd;
	private String pwdkey;
	private String jwwgdm;
	private String ifallcsq; // 是否所有社区权限
	private Integer orderno;
	private String unitname;
	private String unitaddr;

	// Constructors

	/** default constructor */
	public Sysuser() {
	}

	/** minimal constructor */
	public Sysuser(String userid) {
		this.userid = userid;
	}

	/** full constructor */
	public Sysuser(String userid, String username, String passwd,
			String description, Date createtime, Date lastlogontime,
			Date lastlogofftime, String lockstate, Date locktime,
			String lockreason, String orgid, String userkind, String sfzhm,
			String realname, String xb, String tel, Date updatetime) {
		this.userid = userid;
		this.username = username;
		this.passwd = passwd;
		this.description = description;
		this.createtime = createtime;
		this.lastlogontime = lastlogontime;
		this.lastlogofftime = lastlogofftime;
		this.lockstate = lockstate;
		this.locktime = locktime;
		this.lockreason = lockreason;
		this.orgid = orgid;
		this.userkind = userkind;
		this.sfzhm = sfzhm;
		this.realname = realname;
		this.xb = xb;
		this.tel = tel;
		this.updatetime = updatetime;
	}

	// Property accessors
	@Id
	@Column(name = "userid", unique = true, nullable = false, length = 32)
	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Column(name = "username", length = 50)
	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "passwd", length = 32)
	public String getPasswd() {
		return this.passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	@Column(name = "description", length = 50)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "createtime", length = 0)
	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	@Column(name = "lastlogontime", length = 0)
	public Date getLastlogontime() {
		return this.lastlogontime;
	}

	public void setLastlogontime(Date lastlogontime) {
		this.lastlogontime = lastlogontime;
	}

	@Column(name = "lastlogofftime", length = 0)
	public Date getLastlogofftime() {
		return this.lastlogofftime;
	}

	public void setLastlogofftime(Date lastlogofftime) {
		this.lastlogofftime = lastlogofftime;
	}

	@Column(name = "lockstate", length = 1)
	public String getLockstate() {
		return this.lockstate;
	}

	public void setLockstate(String lockstate) {
		this.lockstate = lockstate;
	}

	@Column(name = "locktime", length = 0)
	public Date getLocktime() {
		return this.locktime;
	}

	public void setLocktime(Date locktime) {
		this.locktime = locktime;
	}

	@Column(name = "lockreason", length = 50)
	public String getLockreason() {
		return this.lockreason;
	}

	public void setLockreason(String lockreason) {
		this.lockreason = lockreason;
	}

	@Column(name = "orgid", length = 32)
	public String getOrgid() {
		return this.orgid;
	}

	public void setOrgid(String orgid) {
		this.orgid = orgid;
	}

	@Column(name = "userkind", length = 1)
	public String getUserkind() {
		return this.userkind;
	}

	public void setUserkind(String userkind) {
		this.userkind = userkind;
	}

	@Column(name = "sfzhm", length = 20)
	public String getSfzhm() {
		return this.sfzhm;
	}

	public void setSfzhm(String sfzhm) {
		this.sfzhm = sfzhm;
	}

	@Column(name = "realname", length = 50)
	public String getRealname() {
		return this.realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	@Column(name = "xb", length = 1)
	public String getXb() {
		return this.xb;
	}

	public void setXb(String xb) {
		this.xb = xb;
	}

	@Column(name = "tel", length = 11)
	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	@Column(name = "updatetime", length = 0)
	public Date getUpdatetime() {
		return this.updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	@Column(name = "oldpwd", length = 32)
	public String getOldpwd() {
		return oldpwd;
	}
	@Column(name = "pwdkey", length = 6)
	public String getPwdkey() {
		return pwdkey;
	}
	
	public void setOldpwd(String oldpwd) {
		this.oldpwd = oldpwd;
	}

	public void setPwdkey(String pwdkey) {
		this.pwdkey = pwdkey;
	}

	@Column(name = "jwwgdm", length = 21)
	public String getJwwgdm() {
		return jwwgdm;
	}

	public void setJwwgdm(String jwwgdm) {
		this.jwwgdm = jwwgdm;
	}

	@Column(name = "orderno")
	public Integer getOrderno() {
		return orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	@Column(name = "ifallcsq", length = 12)
	public String getIfallcsq() {
		return ifallcsq;
	}

	public void setIfallcsq(String ifallcsq) {
		this.ifallcsq = ifallcsq;
	}
	@Column(name = "unitname", length = 100)
	public String getUnitname() {
		return unitname;
	}
	@Column(name = "unitaddr", length = 150)
	public String getUnitaddr() {
		return unitaddr;
	}

	public void setUnitname(String unitname) {
		this.unitname = unitname;
	}

	public void setUnitaddr(String unitaddr) {
		this.unitaddr = unitaddr;
	}

}