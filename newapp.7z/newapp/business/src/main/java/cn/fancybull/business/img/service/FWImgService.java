package cn.fancybull.business.img.service;

import cn.fancybull.business.entity.FwImg;
import cn.fancybull.business.img.repository.FWImgRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FWImgService {
    @Autowired
    private FWImgRepository fwImgRepository;

    public void save(FwImg fwImg) {
        fwImgRepository.save(fwImg);
    }
}
