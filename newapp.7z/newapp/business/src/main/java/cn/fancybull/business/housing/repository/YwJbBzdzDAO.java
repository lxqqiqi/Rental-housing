package cn.fancybull.business.housing.repository;

import cn.fancybull.business.housing.dto.YwJbBzdzDTO;
import cn.fancybull.business.test.dto.UserDTO;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.junit.validator.PublicClassValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class YwJbBzdzDAO {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    public List<YwJbBzdzDTO> getYwJbBzdz(YwJbBzdzDTO ywJbBzdzDTO) {
        StringBuffer sb = new StringBuffer();
        sb.append("select kshznfc.yw_jb_bzdz.dzmc ");
        sb.append(" from kshznfc.yw_jb_bzdz ");
        sb.append(" where kshznfc.yw_jb_bzdz.systemid=:systemid ");
        YwJbBzdzDTO ywJbBzdzDTO1 = new YwJbBzdzDTO();
        //固定可以不固定不行
        ywJbBzdzDTO1.setSystemid(ywJbBzdzDTO.getSystemid());
        List<YwJbBzdzDTO> list = commonRepository.queryBySql(sb.toString(), ywJbBzdzDTO1, YwJbBzdzDTO.class);
        return list;
    }
    public List<YwJbBzdzDTO> getsystemid(YwJbBzdzDTO ywJbBzdzDTO) {
        StringBuffer sb = new StringBuffer();
        sb.append("select kshznfc.yw_jb_bzdz.systemid ");
        sb.append(" from kshznfc.yw_jb_bzdz ");
        sb.append(" where kshznfc.yw_jb_bzdz.dzmc=:dzmc ");
        YwJbBzdzDTO ywJbBzdzDTO1 = new YwJbBzdzDTO();
        //固定可以不固定不行
        ywJbBzdzDTO1.setSystemid(ywJbBzdzDTO.getDzmc());
        List<YwJbBzdzDTO> list = commonRepository.queryBySql(sb.toString(), ywJbBzdzDTO1, YwJbBzdzDTO.class);
        return list;
    }
}
