package cn.fancybull.business.audit.control;

import cn.fancybull.business.audit.dto.AuditFwhouseinfoDTO;
import cn.fancybull.business.audit.service.AuditFwhouseinfoService;
import cn.fancybull.business.entity.AuditFwHouseinfo;
import cn.fancybull.business.entity.FwHouseinfo;
import cn.fancybull.business.housing.service.FwHouseinfoService;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/auditfwhouseinfo")
public class AuditFwhouseinfoController {
    @Autowired
    private AuditFwhouseinfoService auditFwhouseinfoService;

    @Autowired
    private FwHouseinfoService fwHouseinfoService;

    @RequestMapping("index")
    public JsonResult<List<FwHouseinfo>> index(String audituserid) {
        List<FwHouseinfo> list = new ArrayList<>();
        List<AuditFwHouseinfo> auditFwHouseinfos = auditFwhouseinfoService.findByAudituserid(audituserid);
        List<String> houseinfoids = new ArrayList<>();
        for(int i=0;i<auditFwHouseinfos.size();i++) {
            houseinfoids.add(auditFwHouseinfos.get(i).getHouseinfoid());
        }
        for(int j=0;j<houseinfoids.size();j++) {
            FwHouseinfo fwHouseinfo =fwHouseinfoService.findByHouseinfoid(houseinfoids.get(j));
            list.add(fwHouseinfo);
        }
        JsonResult<List<FwHouseinfo>> jsonResult = new JsonResult<List<FwHouseinfo>>();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        jsonResult.setData(list);
        return jsonResult;
    }



    /**
     * 增加审核人和房屋表数据
     * 需要传入houseinfoid,List数组audituserids
     *
      * @param auditFwhouseinfoDTO
     */
    @RequestMapping("/edit")
    public JsonResult edit(@RequestBody AuditFwhouseinfoDTO auditFwhouseinfoDTO) {
        int a =auditFwhouseinfoDTO.getAudituserids().size();
        for(int i=0;i<a;i++) {
            AuditFwHouseinfo auditFwHouseinfo = new AuditFwHouseinfo();
            auditFwHouseinfo.setAudituserid(auditFwhouseinfoDTO.getAudituserids().get(i));
            auditFwHouseinfo.setHouseinfoid(auditFwhouseinfoDTO.getHouseinfoid());
            auditFwhouseinfoService.save(auditFwHouseinfo);
        }
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("请求成功");
        return jsonResult;
    }
}
