package cn.fancybull.business.housing.repository;

import cn.fancybull.business.entity.FwHouseinfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FWHouseinfoRepository extends JpaRepository<FwHouseinfo,String> {
    List<FwHouseinfo> findByUserid(String userid);
    FwHouseinfo findByHouseinfoid(String houseinfoid);

}
