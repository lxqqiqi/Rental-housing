package cn.fancybull.common.dto;

import java.sql.Timestamp;
import java.util.List;

public class FwFeedbackDTO {
    private String fknr;

    public String getFknr() {
        return fknr;
    }

    public void setFknr(String fknr) {
        this.fknr = fknr;
    }

    public List<String> getFktp() {
        return fktp;
    }

    public void setFktp(List<String> fktp) {
        this.fktp = fktp;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    private List<String> fktp;
    private String userid;
}
