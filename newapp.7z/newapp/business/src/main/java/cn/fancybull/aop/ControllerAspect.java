package cn.fancybull.aop;

import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.model.JsonResult;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * 控制层的切面，用于记录请求日志信息
 */
@Aspect
@Configuration
public class ControllerAspect {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private RedisService redisService;
    @Around("execution(* cn.fancybull..*control..*(..)) && @within(org.springframework.web.bind.annotation.RestController) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
    public Object aroundMethod(ProceedingJoinPoint pjp)throws Throwable{
        //获取请求报文头部元数据
        ServletRequestAttributes requestAttributes=(ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        //获取请求对象
        HttpServletRequest request=requestAttributes.getRequest();


//        从request中获取过滤器传过来的权限验证参数，判断是否继续执行进入Control。

//        String a = request.getRequestURI();
//        String b = "/wx/login";
//        boolean c = b.equalsIgnoreCase(a);
//        if (b.equalsIgnoreCase(a)!=true) {
//            String token = request.getHeader("wxtoken");
//            String openid = request.getHeader("openid");
//             redisService = new RedisService();
//            String iftoken = redisService.getValue(openid);
//
//            if(token.equals(iftoken)!=true) {
//                JsonResult jsonResult = new JsonResult();
//                jsonResult.setCode("304");
//                jsonResult.setMsg("未登录或登录超时");
//                return jsonResult;
//            }
//        }







        long tick = System.currentTimeMillis();
        // 执行进入控制层
        Object retobj = pjp.proceed();
        logger.info("请求时间：" + (System.currentTimeMillis()-tick));
        return retobj;
    }
}
