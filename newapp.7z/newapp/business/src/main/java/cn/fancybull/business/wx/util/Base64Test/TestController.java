package cn.fancybull.business.wx.util.Base64Test;


import static cn.fancybull.business.wx.util.Base64Util.generateImage;
import static cn.fancybull.business.wx.util.Base64Util.getImageStr;

public class TestController {
    public static void main(String[] args) {
        String strImg = getImageStr("F:/Img/u=3541412018,2081784518&fm=26&gp=0.jpg");
        System.out.print(strImg);
        generateImage(strImg, "F:/Img2/86619-107.jpg");
    }
}
