package cn.fancybull.business.livingpeople.repository;

import cn.fancybull.business.housing.dto.YwJbBzdzDTO;
import cn.fancybull.business.livingpeople.dto.YwJbSyrkjbxxDTO;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class SyrkdjxxDAO {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    public List<YwJbSyrkjbxxDTO> selectidsyrk(YwJbSyrkjbxxDTO ywJbSyrkjbxxDTO) {
        StringBuffer sb = new StringBuffer();
        sb.append("select kshznfc.yw_jb_syrkjbxx.idsyrk,kshznfc.yw_jb_syrkjbxx.lv_gmsfhm ");
        sb.append(" from kshznfc.yw_jb_syrkjbxx ");
        sb.append("where kshznfc.yw_jb_syrkjbxx.lv_gmsfhm=:sfzhm");
        YwJbSyrkjbxxDTO ywJbSyrkjbxxDTO1 = new YwJbSyrkjbxxDTO();
        ywJbSyrkjbxxDTO1.setSfzhm(ywJbSyrkjbxxDTO.getSfzhm());
        List<YwJbSyrkjbxxDTO> list =  commonRepository.queryBySql(sb.toString(), ywJbSyrkjbxxDTO1, YwJbSyrkjbxxDTO.class);
        return list;
    }
}
