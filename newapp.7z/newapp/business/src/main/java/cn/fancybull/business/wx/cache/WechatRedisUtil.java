package cn.fancybull.business.wx.cache;
import java.util.concurrent.TimeUnit;

import cn.fancybull.business.wx.util.SpringUtil;
import org.springframework.data.redis.core.RedisTemplate;


@SuppressWarnings("rawtypes")
public class WechatRedisUtil {
    private static RedisTemplate jedisTemplate ;

    private WechatRedisUtil(){}

    static {
        jedisTemplate = (RedisTemplate) SpringUtil.getBean("wechatJedisTemplate");
    }
    /**
     * 添加到队列
     */
    public static Long pushToList(String key, Object value) {
        return jedisTemplate.opsForList().leftPush(key, value);
    }
    /**
     * 从队列里取出
     */
    public static Object popfromList(String key) {
        return jedisTemplate.opsForList().rightPop(key);
    }

    /**
     * 字符串操作：新增或修改
     */
    public static void putValue(String key, Object value) {
        jedisTemplate.opsForValue().set(key, value);
    }

    /**
     * 字符串操作：新增或修改
     * @param key
     * @param value
     * @param time 有限时间，单位为秒
     */
    public static void putValue(String key, Object value, long time) {
        jedisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
    }

    /**
     * 字符串操作：取值
     */
    public static Object getValue(String key) {
        return jedisTemplate.opsForValue().get(key);
    }

    /**
     * 设置缓存参数有效时间
     * @param key
     * @param time
     */
    public static void expire(String key, long time){
        jedisTemplate.expire(key, time, TimeUnit.SECONDS);
    }

}
