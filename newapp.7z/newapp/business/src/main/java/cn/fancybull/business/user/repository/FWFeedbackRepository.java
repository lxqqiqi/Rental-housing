package cn.fancybull.business.user.repository;

import cn.fancybull.business.entity.FwFeedback;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FWFeedbackRepository extends JpaRepository<FwFeedback,String> {
    List<FwFeedback> findByUserid(String userid);
}
