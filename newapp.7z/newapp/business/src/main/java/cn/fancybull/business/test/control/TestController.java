package cn.fancybull.business.test.control;

import cn.fancybull.framework.common.control.BaseController;
import cn.fancybull.business.test.entity.Sysuser;
import cn.fancybull.business.test.service.UserService;
import cn.fancybull.framework.redis.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping(value="/test")
public class TestController extends BaseController {
    @Autowired
    private UserService us;

    @RequestMapping(value="/hello")
    public Sysuser hello(@RequestBody Sysuser user) {
        try {
            request.getParameter("dddd");
            return us.saveUser();
        }
        catch (Exception e) {
            return null;
        }
    }
}
