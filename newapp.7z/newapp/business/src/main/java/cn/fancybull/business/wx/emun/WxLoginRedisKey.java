package cn.fancybull.business.wx.emun;

public class WxLoginRedisKey {

    /**
     * 保存用户的token，相当于session
     */
    public static final String openid_unionid = "openid_unionid_";

    /**
     * 保存用户的token，相当于session
     */
    public static final String unionid_token = "unionid_";

    /**
     * 保存用户的实名认证信息
     */
    public static final String wx_userinfo = "wxtoken_";

    /**
     * 用来保存微信小程序的Access Token
     */
    public static final String wx_access_token = "wx_access_token";

    /**
     * 用来存放短息验证码
     */
    public static final String smscode="smscode_";

    /**
     * 过滤器和AOP之间传输session校验结果的key
     */
    public static final String SESSION_CHECK_NAME = "session_check_name";

    /**
     * SESSION校验成功
     */
    public static final String SESSION_CHECK_VALUE_1 = "1";

    /**
     * 为传入openid或token
     */
    public static final String SESSION_CHECK_VALUE_2 = "2";

    /**
     * 用户未登录
     */
    public static final String SESSION_CHECK_VALUE_3 = "3";

    /**
     * token错误
     */
    public static final String SESSION_CHECK_VALUE_4 = "4";
}
