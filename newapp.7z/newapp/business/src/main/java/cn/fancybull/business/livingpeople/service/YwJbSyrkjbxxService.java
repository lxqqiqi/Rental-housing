package cn.fancybull.business.livingpeople.service;

import cn.fancybull.business.livingpeople.dto.YwJbSyrkjbxxDTO;
import cn.fancybull.business.livingpeople.repository.SyrkdjxxDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class YwJbSyrkjbxxService {
    @Autowired
    private SyrkdjxxDAO syrkdjxxDAO;
//身份证号码不能空
@Transactional
    public List<YwJbSyrkjbxxDTO> selectidsyrk(YwJbSyrkjbxxDTO ywJbSyrkjbxxDTO) {
       return syrkdjxxDAO.selectidsyrk(ywJbSyrkjbxxDTO);
    }
}
