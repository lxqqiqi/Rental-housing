package cn.fancybull.business.user.dto;

import cn.fancybull.business.entity.FwMessage;
import cn.fancybull.business.entity.FwMessagedetail;

import java.util.List;

public class FWMessageDTO extends FwMessage {
//    private FwMessage fwMessage;

//    public FwMessage getFwMessage() {
//        return fwMessage;
//    }
//
//    public void setFwMessage(FwMessage fwMessage) {
//        this.fwMessage = fwMessage;
//    }

    private List<FwMessagedetail> fwMessagedetailList;

    public List<FwMessagedetail> getFwMessagedetailList() {
        return fwMessagedetailList;
    }

    public void setFwMessagedetailList(List<FwMessagedetail> fwMessagedetailList) {
        this.fwMessagedetailList = fwMessagedetailList;
    }
}
