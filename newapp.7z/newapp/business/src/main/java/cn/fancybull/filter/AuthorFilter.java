package cn.fancybull.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 权限认证过滤器<br>
 * 执行接口访问权限控制。需与控制层的AOP进行联动
 */
@Component
@ServletComponentScan
@WebFilter(urlPatterns = "/*",filterName = "authorFilter")
public class AuthorFilter implements Filter {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = ((HttpServletResponse) servletResponse);
        String uri = request.getRequestURI().replaceFirst(request.getContextPath(), "");
        ServletContext context = request.getSession().getServletContext();

        ///  过滤器的控制实现代码
        /// 过滤结果可以写入到request中，在控制层的AOP进行处理


        filterChain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}
