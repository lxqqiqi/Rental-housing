package cn.fancybull.business.housing.service;


import cn.fancybull.business.entity.FwHouseinfo;
import cn.fancybull.business.housing.repository.FWHouseinfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FwHouseinfoService {

    @Autowired
    private FWHouseinfoRepository fwHouseinfoRepository;
    public void save(FwHouseinfo fwHouseinfo) {
        fwHouseinfoRepository.save(fwHouseinfo);
    }

    public List<FwHouseinfo> selectFWHouse (String userid) {
        List<FwHouseinfo> fwHouseinfos = fwHouseinfoRepository.findByUserid(userid);
        return  fwHouseinfos;
    }

    public void delete(FwHouseinfo fw) {
        fwHouseinfoRepository.delete(fw);
    }

    public FwHouseinfo selectByHouseinfoid(String houseinfoid) {
        return fwHouseinfoRepository.findByHouseinfoid(houseinfoid);
    }

    public void flush() {
        fwHouseinfoRepository.flush();
    }

   public FwHouseinfo findByHouseinfoid(String houseinfoid) {
        return fwHouseinfoRepository.findByHouseinfoid(houseinfoid);
   }
}
