package cn.fancybull.business.test.service;

import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import cn.fancybull.business.test.entity.Sysuser;
import cn.fancybull.business.test.repository.SysuserDAO;
import cn.fancybull.business.test.repository.SysuserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private SysuserRepository sur;
    @Autowired
    private SysuserDAO userdao;
    @Resource
    private RedisService redis;
    //@Transactional
    public Sysuser saveUser() throws Exception {
//        Sysuser user = new Sysuser();
//        user.setUserid("aaa1115");
//        user.setUsername("test");
//        commonRepository.save(user);
//
//        Sysuser user1 = new Sysuser();
//        user1.setUserid("aaa1116");
//        user1.setUsername("test2");
//        sur.save(user1);
        List list = userdao.getUserList();
        logger.info("size"+list.size());
        String abc = redis.getValue("abc");
        logger.info(abc);
        //return user;
        return null;
    }
}
