package cn.fancybull.model.pack;

import java.sql.Timestamp;

public class FWMessageAndDetail {
    private long messageid;
    private String userid;

    public long getMessageid() {
        return messageid;
    }

    public void setMessageid(long messageid) {
        this.messageid = messageid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getMessagetype() {
        return messagetype;
    }

    public void setMessagetype(String messagetype) {
        this.messagetype = messagetype;
    }

    public Timestamp getMessagetime() {
        return messagetime;
    }

    public void setMessagetime(Timestamp messagetime) {
        this.messagetime = messagetime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIfread() {
        return ifread;
    }

    public void setIfread(String ifread) {
        this.ifread = ifread;
    }

    public Timestamp getReadtime() {
        return readtime;
    }

    public void setReadtime(Timestamp readtime) {
        this.readtime = readtime;
    }

    public Long getEventid() {
        return eventid;
    }

    public void setEventid(Long eventid) {
        this.eventid = eventid;
    }

    public long getMessagedetailid() {
        return messagedetailid;
    }

    public void setMessagedetailid(long messagedetailid) {
        this.messagedetailid = messagedetailid;
    }

    public String getColumnname() {
        return columnname;
    }

    public void setColumnname(String columnname) {
        this.columnname = columnname;
    }

    public String getColumnvalue() {
        return columnvalue;
    }

    public void setColumnvalue(String columnvalue) {
        this.columnvalue = columnvalue;
    }

    private String messagetype;
    private Timestamp messagetime;
    private String title;
    private String ifread;
    private Timestamp readtime;
    private Long eventid;
    private long messagedetailid;
    private String columnname;
    private String columnvalue;
}
