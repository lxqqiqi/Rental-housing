package cn.fancybull.business.user.dto;

public class FWFeedbackDTO {
    private String fknr;
    private String fktp;
    private String userid;

    public String getFknr() {
        return fknr;
    }

    public void setFknr(String fknr) {
        this.fknr = fknr;
    }

    public String getFktp() {
        return fktp;
    }

    public void setFktp(String fktp) {
        this.fktp = fktp;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getFksj() {
        return fksj;
    }

    public void setFksj(String fksj) {
        this.fksj = fksj;
    }

    private String fksj;
}
