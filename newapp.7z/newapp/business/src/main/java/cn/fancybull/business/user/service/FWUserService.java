package cn.fancybull.business.user.service;

import cn.fancybull.business.entity.FwUser;
import cn.fancybull.business.user.repository.FWUserRepository;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class FWUserService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    @Resource
    private FWUserRepository fwUserRepository;
    public List<FwUser> findByOpenid(String openid) {
        return fwUserRepository.findByOpenid(openid);
    }

    public void save(FwUser fwUser) {
        fwUserRepository.save(fwUser);
    }
    public void delete(FwUser fwUser) {fwUserRepository.delete(fwUser);}
    public FwUser findByUSerid(String userid) {
       return fwUserRepository.findByUserid(userid);
    }
}
