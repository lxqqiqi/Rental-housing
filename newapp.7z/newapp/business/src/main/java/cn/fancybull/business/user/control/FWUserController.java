package cn.fancybull.business.user.control;

import cn.fancybull.business.entity.FwUser;
import cn.fancybull.business.housing.service.YwJbBzdzService;
import cn.fancybull.business.user.service.FWUserService;
import cn.fancybull.business.wx.util.UUidUtil;
import cn.fancybull.framework.common.util.Cache;

import cn.fancybull.framework.common.util.JuheSms;
import cn.fancybull.interceptor.WebExceptionAspectGetMapper;
import cn.fancybull.model.CallWebPage;
import cn.fancybull.model.JsonResult;
import cn.fancybull.model.Preventsql;
import cn.fancybull.model.pack.FWUserHome;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/fwuser")
public class FWUserController {
    private CallWebPage callWebPage;

    Cache<String,String> cache = new Cache<String,String>(100000);

    @Autowired
    private FWUserService fwUserService;



    @RequestMapping("/sendsums")
    public JsonResult testsums(String phone) {
        int codes = (int) (Math.random() * (99999 - 10000));
        String code = String.valueOf(codes);
        cache.put(phone,code);
        JuheSms.setSms(phone, code);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("发送成功");
        System.out.println(cache.toString());
        return jsonResult;
    }

    @RequestMapping("/ifsums")
    public JsonResult testifsums(String phone, String code) {
        JsonResult jsonResult = new JsonResult();
        try {
            if (cache.get(phone).equals(code)) {
                jsonResult.setCode("200");
                jsonResult.setMsg("验证成功");
                cache.remove(phone);
                return jsonResult;
            }
            jsonResult.setCode("300");
            jsonResult.setMsg("验证失败");
            return jsonResult;
        } catch (NullPointerException e) {
            jsonResult.setCode("300");
            jsonResult.setMsg("出现异常，请重新尝试");
            return jsonResult;
        }

    }

    /**
     * 首页列表
     *
     */
    @RequestMapping("/home")
    public JsonResult<FWUserHome> home(String openid) {
        JsonResult<FWUserHome> jsonResult= new JsonResult<FWUserHome>();

        FWUserHome fwUserHome = new FWUserHome();
        List<FwUser> fwUser = fwUserService.findByOpenid(openid);
        if(fwUser.size()!=0) {
            jsonResult.setCode("200");
            jsonResult.setMsg("成功");
            fwUserHome.setDqjf(fwUser.get(0).getDqjf());
            fwUserHome.setPfdj(fwUser.get(0).getPfdj());
            fwUserHome.setUserid(fwUser.get(0).getUserid());

            if(Integer.parseInt(fwUserHome.getDqjf())<=100&&Integer.parseInt(fwUserHome.getDqjf())>=0) {
                if(fwUserHome.getPfdj().equals("0")) {

                } else {
                    fwUserHome.setPfdj("0");
                    FwUser fwUser1 = fwUser.get(0);
                    fwUser1.setPfdj("0");
                    fwUserService.save(fwUser1);
                }
            } else if(Integer.parseInt(fwUserHome.getDqjf())<=200) {
                if(fwUserHome.getPfdj().equals("1")) {

                } else {
                    fwUserHome.setPfdj("1");
                    FwUser fwUser1 = fwUser.get(0);
                    fwUser1.setPfdj("1");
                    fwUserService.save(fwUser1);

                }
            } else {
                if(fwUserHome.getPfdj().equals("2")) {

                } else {
                    fwUserHome.setPfdj("2");
                    FwUser fwUser1 = fwUser.get(0);
                    fwUser1.setPfdj("2");
                    fwUserService.save(fwUser1);
                }
            }

            if (fwUser.get(0).getSfzhm() != null && fwUser.get(0).getSfzhm() != "") {
                fwUserHome.setSm("1");//实名
            } else {
                fwUserHome.setSm("0");//0没实名
            }
            jsonResult.setData(fwUserHome);
        } else {
            jsonResult.setCode("300");
            jsonResult.setMsg("没有该用户");
        }
        return jsonResult;
    }


    /**
     * 个人信息
     * @param openid
     * @return
     */
    @RequestMapping("/index")
    public JsonResult<FwUser> index(String openid) {

        List<FwUser> fwUserList = fwUserService.findByOpenid(openid);
        JsonResult<FwUser> jsonResult = new JsonResult<FwUser>();
        if(fwUserList.size()!=0) {
            FwUser fwUser = fwUserList.get(0);
            jsonResult.setCode("200");
            jsonResult.setMsg("成功");
            jsonResult.setData(fwUser);
        } else {
            jsonResult.setCode("300");
            jsonResult.setMsg("失败");
        }

        return jsonResult;
    }

    @RequestMapping("/ifauthentication")
    public JsonResult<FWUserHome> ifauthentication(FwUser fwUser) {
        JsonResult jsonResult = new JsonResult();
        List<FwUser> fwUserList = fwUserService.findByOpenid(fwUser.getOpenid());
        FWUserHome fwUserHome = new FWUserHome();
        if(fwUserList.size()==0) {
            jsonResult.setCode("200");
            jsonResult.setMsg("未实名认证");

            fwUserHome.setSm("0");
            jsonResult.setData(fwUserHome);
        } else {
            jsonResult.setCode("200");
            jsonResult.setMsg("已实名");
            fwUserHome.setSm("1");
            fwUserHome.setUserid(fwUserList.get(0).getUserid());
            jsonResult.setData(fwUserHome);
        }
        return jsonResult;
    }

    /**
     * 用户实名注册
     * @param fwUser
     * @param ret
     * @return
     */
    @RequestMapping("/authentication")
    public JsonResult authentication(@Valid FwUser fwUser, BindingResult ret) {
        int nowdqjf = 0;
        String userid = UUidUtil.getUUID();
        if(fwUser.getUserid()==null) {
            fwUser.setUserid(userid);
        }
        WebExceptionAspectGetMapper webExceptionAspectGetMapper = new WebExceptionAspectGetMapper();
        if(fwUser.getZcsj()==null) {
            Timestamp nowdate = new Timestamp(System.currentTimeMillis());
            fwUser.setZcsj(nowdate);
            Date dates = new Date();
            dates = nowdate;
            System.out.println("当前时间" + dates);
        }

        if(fwUser.getSfzhm()!=null) {
            String date = fwUser.getSfzhm().substring(6, 14);
            fwUser.setCsrq(date);
            String xb = fwUser.getSfzhm().substring(16,17);
            if(Integer.parseInt(xb)%2!=0) {
                fwUser.setXb("1");//1男，2女
            } else {
                fwUser.setXb("2");
            }
        }

        webExceptionAspectGetMapper.validate(ret);
        if(fwUser.getHjdz()!=null) {
            Preventsql preventsql = new Preventsql();
            preventsql.sqlValidate(fwUser.getHjdz());
        }
        if(fwUser.getUserid()==null) {
            if(fwUser.getSfzhm()!=null) {
                if(fwUser.getSfzhm().length()<=18&&fwUser.getSfzhm().length()>=15) {
                    nowdqjf += 10;
                    fwUser.setYhzt("1");
                }
            } else {
                fwUser.setYhzt("0");
            }
            if(fwUser.getDqjf()!=null) {
                String befordqjfs = fwUser.getDqjf();
                int befordqjf = Integer.parseInt(befordqjfs);
                nowdqjf +=befordqjf;
                fwUser.setDqjf(String.valueOf(nowdqjf));
               if(nowdqjf<=100) {
                   fwUser.setPfdj("0");
               } else if(nowdqjf<=200) {
                   fwUser.setPfdj("1");
                } else {
                   fwUser.setPfdj("2");
               }

            } else {
                fwUser.setDqjf(String.valueOf(nowdqjf));
                fwUser.setPfdj("0");
            }

        }
        fwUserService.save(fwUser);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("成功");
        jsonResult.setData(fwUser);
        return jsonResult;
    }





    /**
     * 需要参数userid
     * @param fwUser
     * @return
     */
    @RequestMapping("/delete")
    public JsonResult delete(FwUser fwUser){
        fwUserService.delete(fwUser);
        JsonResult jsonResult = new JsonResult();
        jsonResult.setCode("200");
        jsonResult.setMsg("成功");
        return jsonResult;
    }

}
