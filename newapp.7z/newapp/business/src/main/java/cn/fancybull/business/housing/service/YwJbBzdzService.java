package cn.fancybull.business.housing.service;

import cn.fancybull.business.housing.dto.YwJbBzdzDTO;
import cn.fancybull.business.housing.repository.YwJbBzdzDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class YwJbBzdzService {
    @Autowired
    private YwJbBzdzDAO ywJbBzdzDAO;
    @Transactional
    public List<YwJbBzdzDTO> findBysystemid(YwJbBzdzDTO ywJbBzdzDTO) {
        return ywJbBzdzDAO.getYwJbBzdz(ywJbBzdzDTO);
    }
    public List<YwJbBzdzDTO> getsystemid(YwJbBzdzDTO ywJbBzdzDTO) {
        return ywJbBzdzDAO.getsystemid(ywJbBzdzDTO);
    }
}
