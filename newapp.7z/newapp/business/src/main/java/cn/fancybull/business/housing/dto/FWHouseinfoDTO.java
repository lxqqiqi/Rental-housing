package cn.fancybull.business.housing.dto;

public class FWHouseinfoDTO {
    private int nowPeople;//当前人数
    private int totalPeople;//总人数
    private Integer lvfwczjs;//出租间数
    private String dzmc;//标准地址

    public String getDzmc() {
        return dzmc;
    }

    public void setDzmc(String dzmc) {
        this.dzmc = dzmc;
    }

    public int getNowPeople() {
        return nowPeople;
    }

    public void setNowPeople(int nowPeople) {
        this.nowPeople = nowPeople;
    }

    public int getTotalPeople() {
        return totalPeople;
    }

    public void setTotalPeople(int totalPeople) {
        this.totalPeople = totalPeople;
    }

    public Integer getLvfwczjs() {
        return lvfwczjs;
    }

    public void setLvfwczjs(Integer lvfwczjs) {
        this.lvfwczjs = lvfwczjs;
    }

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid;
    }

    private String systemid;//标准地址编码
}
