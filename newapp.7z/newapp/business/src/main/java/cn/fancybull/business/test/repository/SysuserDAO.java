package cn.fancybull.business.test.repository;

import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import cn.fancybull.business.test.dto.UserDTO;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class SysuserDAO {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;

    public List<UserDTO> getUserList(){
        StringBuffer sb = new StringBuffer();
        sb.append("select u.userid,u.username,u.tel,u.orgid,o.orgname ");
        sb.append(" from sysuser u, sysorg o ");
        sb.append(" where u.orgid=o.orgid ");
        sb.append(" and u.tel=:tel ");
        sb.append(" and u.username like :username");

        UserDTO param = new UserDTO();
        param.setTel("13599219427");

        List<UserDTO> list = commonRepository.queryBySql(sb.toString(), param, UserDTO.class);
        redis.putValue("abc", "123");
        logger.info("测试日志输出");
        return list;
    }
}
