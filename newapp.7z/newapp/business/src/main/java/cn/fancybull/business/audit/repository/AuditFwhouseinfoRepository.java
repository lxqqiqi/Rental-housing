package cn.fancybull.business.audit.repository;

import cn.fancybull.business.entity.AuditFwHouseinfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditFwhouseinfoRepository extends JpaRepository<AuditFwHouseinfo,String> {
    public List<AuditFwHouseinfo> findByAudituserid(String audituserid);
}
