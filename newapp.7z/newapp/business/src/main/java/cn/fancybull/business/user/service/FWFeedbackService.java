package cn.fancybull.business.user.service;

import cn.fancybull.business.entity.FwFeedback;
import cn.fancybull.business.user.repository.FWFeedbackRepository;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class FWFeedbackService {
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    @Resource
    private FWFeedbackRepository fwFeedbackRepository;

    public void sava(FwFeedback fwFeedback) {
        fwFeedbackRepository.save(fwFeedback);
    }

    public List<FwFeedback> findByUserid(String userid) {
        return fwFeedbackRepository.findByUserid(userid);
    }
}
