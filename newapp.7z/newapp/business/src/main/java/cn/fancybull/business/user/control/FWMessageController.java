package cn.fancybull.business.user.control;

import cn.fancybull.business.entity.FwMessage;
import cn.fancybull.business.entity.FwMessagedetail;
import cn.fancybull.business.user.dto.FWMessageDTO;
import cn.fancybull.business.user.service.FWMessageService;
import cn.fancybull.business.user.service.FWMessagedetailService;
import cn.fancybull.model.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/fwmessage")
public class FWMessageController {
    @Autowired
    private FWMessageService fwMessageService;
    @Autowired
    private FWMessagedetailService fwMessagedetailService;

    @RequestMapping("/index")
    public JsonResult<List<FWMessageDTO>> index(String userid) {
        JsonResult<List<FWMessageDTO>> jsonResult = new JsonResult<List<FWMessageDTO>>();
        if (userid != null) {
            List<FwMessage> fwMessageList = fwMessageService.selectMessage(userid);
            List<FWMessageDTO> fwMessageDTOList = new ArrayList<FWMessageDTO>();
            for (int a = 0; a < fwMessageList.size(); a++) {
                FWMessageDTO fwMessageDTO = new FWMessageDTO();
                fwMessageDTO.setMessageid(fwMessageList.get(a).getMessageid());
                fwMessageDTO.setEventid(fwMessageList.get(a).getEventid());
                fwMessageDTO.setReadtime(fwMessageList.get(a).getReadtime());
                fwMessageDTO.setIfread(fwMessageList.get(a).getIfread());
                fwMessageDTO.setTitle(fwMessageList.get(a).getTitle());
                fwMessageDTO.setMessagetime(fwMessageList.get(a).getMessagetime());
                fwMessageDTO.setMessagetype(fwMessageList.get(a).getMessagetype());
                fwMessageDTO.setUserid(fwMessageList.get(a).getUserid());
//                fwMessageDTOList.add(fwMessageDTO);
//                fwMessageDTO.setFwMessage(fwMessageList.get(a));

                    List<FwMessagedetail> fwMessagedetails = fwMessagedetailService.selectByMessageid(fwMessageList.get(a).getMessageid());
                    fwMessageDTO.setFwMessagedetailList(fwMessagedetails);
                fwMessageDTOList.add(fwMessageDTO);
            }
            jsonResult.setCode("200");
            jsonResult.setMsg("请求成功");
            jsonResult.setData(fwMessageDTOList);
        } else {
            jsonResult.setCode("300");
            jsonResult.setMsg("缺少参数");
        }

        return jsonResult;

    }

}
