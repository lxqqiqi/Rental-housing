package cn.fancybull.business.wx.control;

import cn.fancybull.business.entity.FwUser;
import cn.fancybull.business.user.service.FWUserService;
import cn.fancybull.business.wx.dto.ReturnWXDTO;
import cn.fancybull.business.wx.dto.WxDTO;
import cn.fancybull.business.wx.util.UUidUtil;
import cn.fancybull.business.wx.util.WechatRequestUtil;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.model.JsonResult;
import cn.fancybull.model.pack.FWUserHome;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import org.hibernate.secure.internal.JaccSecurityListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sun.plugin.util.UIUtil;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/wx")
public class WxController {
   @Autowired
   private RedisService redisService;
   @Autowired
   private FWUserService fwUserService;

   @RequestMapping("/login")
    public JsonResult<ReturnWXDTO> login(@RequestBody WxDTO wxDTO) {
       JSONObject wx =  WechatRequestUtil.getWxOpenid(wxDTO.getCode());
       String openid = (String) wx.get("openid");
       String access_token=null;
       if(redisService.getValue("access_token")==null) {
           JSONObject json = WechatRequestUtil.getAccecctoken();
           access_token = (String) json.get("access_token");
           redisService.putValue("access_token", access_token,7200);
       } else {
           access_token = redisService.getValue("access_token");
       }

       JsonResult<ReturnWXDTO> jsonResult;
       jsonResult = new JsonResult<ReturnWXDTO>();

       String wxtoken = UUidUtil.getUUID();
       String unionid = null;
       ReturnWXDTO returnWXDTO = new ReturnWXDTO();
       if(openid!=null) {
           redisService.putValue(openid, wxtoken, 7200);
//           JSONObject wxunionid =  WechatRequestUtil.getUserInfo(openid);
//           unionid = (String) wxunionid.get("unionid");
//           returnWXDTO.setUnionid(unionid);
       }
       System.out.println(wxDTO.getCode());
       System.out.println(access_token);
      System.out.println(openid);
       System.out.println(wxtoken);
//       System.out.println(unionid);
       FwUser fwUser;
       List<FwUser> fwUserList =fwUserService.findByOpenid(openid);
       if(fwUserList.size()!=0) {
           fwUser = fwUserList.get(0);
           returnWXDTO.setFwUser(fwUser);
           if (fwUserList.get(0).getSfzhm() == null && fwUserList.get(0).getSfzhm()=="") {
               returnWXDTO.setSm("0");
           } else {
               returnWXDTO.setSm("1");
           }
       } else {
           returnWXDTO.setSm("0");
       }
       jsonResult.setCode("200");
       jsonResult.setMsg("请求成功");
       returnWXDTO.setWx(wx);
       returnWXDTO.setWxtoken(wxtoken);
       jsonResult.setData(returnWXDTO);
       return jsonResult;
   }
}
