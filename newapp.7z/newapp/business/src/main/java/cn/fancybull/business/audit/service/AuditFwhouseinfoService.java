package cn.fancybull.business.audit.service;

import cn.fancybull.business.audit.repository.AuditFwhouseinfoRepository;
import cn.fancybull.business.entity.AuditFwHouseinfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditFwhouseinfoService {
    @Autowired
    AuditFwhouseinfoRepository auditFwhouseinfoRepository;
    public List<AuditFwHouseinfo> findByAudituserid(String audituserid){
        return auditFwhouseinfoRepository.findByAudituserid(audituserid);
    }

    public void save(AuditFwHouseinfo auditFwHouseinfo) {
        auditFwhouseinfoRepository.save(auditFwHouseinfo);
    }

}
