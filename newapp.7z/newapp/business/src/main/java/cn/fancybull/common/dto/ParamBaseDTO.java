package cn.fancybull.common.dto;

import java.io.Serializable;

/**
 * 基础DTO
 * @param <T>
 */
public class ParamBaseDTO <T extends Object> implements Serializable {
    private Integer code;
    private String msg;

    private T result;

    public Integer getCode() {
        return code;
    }
    public String getMsg() {
        return msg;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public T getResult() {
        return result;
    }
    public void setResult(T result) {
        this.result = result;
    }
}
