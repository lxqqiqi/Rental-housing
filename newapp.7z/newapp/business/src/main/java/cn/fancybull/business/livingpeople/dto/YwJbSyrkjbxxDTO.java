package cn.fancybull.business.livingpeople.dto;

public class YwJbSyrkjbxxDTO {
    private String idsyrk;//实有人口id
    private String sfzhm;

    public String getSfzhm() {
        return sfzhm;
    }

    public void setSfzhm(String sfzhm) {
        this.sfzhm = sfzhm;
    }

    public String getIdsyrk() {
        return idsyrk;
    }

    public void setIdsyrk(String idsyrk) {
        this.idsyrk = idsyrk;
    }
}
