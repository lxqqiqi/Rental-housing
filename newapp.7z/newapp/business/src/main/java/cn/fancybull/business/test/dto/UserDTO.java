package cn.fancybull.business.test.dto;

import cn.fancybull.framework.common.dto.BaseDTO;

import java.util.Date;

public class UserDTO extends BaseDTO {
    private String userid;
    private String username;
    private String passwd;
    private String description;
    private Date createtime;
    private Date lastlogontime;
    private Date lastlogofftime;
    private String lockstate;
    private Date locktime;
    private String lockreason;
    private String orgid;
    private String userkind;
    private String sfzhm;
    private String realname;
    private String xb;
    private String tel;
    private String orgname;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getLastlogontime() {
        return lastlogontime;
    }

    public void setLastlogontime(Date lastlogontime) {
        this.lastlogontime = lastlogontime;
    }

    public Date getLastlogofftime() {
        return lastlogofftime;
    }

    public void setLastlogofftime(Date lastlogofftime) {
        this.lastlogofftime = lastlogofftime;
    }

    public String getLockstate() {
        return lockstate;
    }

    public void setLockstate(String lockstate) {
        this.lockstate = lockstate;
    }

    public Date getLocktime() {
        return locktime;
    }

    public void setLocktime(Date locktime) {
        this.locktime = locktime;
    }

    public String getLockreason() {
        return lockreason;
    }

    public void setLockreason(String lockreason) {
        this.lockreason = lockreason;
    }

    public String getOrgid() {
        return orgid;
    }

    public void setOrgid(String orgid) {
        this.orgid = orgid;
    }

    public String getUserkind() {
        return userkind;
    }

    public void setUserkind(String userkind) {
        this.userkind = userkind;
    }

    public String getSfzhm() {
        return sfzhm;
    }

    public void setSfzhm(String sfzhm) {
        this.sfzhm = sfzhm;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getXb() {
        return xb;
    }

    public void setXb(String xb) {
        this.xb = xb;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }
}
