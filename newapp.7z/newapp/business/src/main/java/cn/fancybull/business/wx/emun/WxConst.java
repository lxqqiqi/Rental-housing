package cn.fancybull.business.wx.emun;

public class WxConst {
    /**
     * 微信小程序的APPID
     */
    public static final String appid = "wxf1d790a93cc329f9";


    /**
     * 微信小程序的App Secret
     */
    public static final String App_Secret = "cd20a5e116c79ffe9ec496755e65e37e";
}
