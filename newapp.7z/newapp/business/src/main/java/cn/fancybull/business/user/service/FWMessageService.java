package cn.fancybull.business.user.service;

import cn.fancybull.business.entity.FwMessage;
import cn.fancybull.business.entity.FwMessagedetail;
import cn.fancybull.business.user.dto.FWMessageDTO;
import cn.fancybull.business.user.repository.FWMessageDAO;
import cn.fancybull.business.user.repository.FWMessageRepository;
import cn.fancybull.business.user.repository.FWMessagedetailRepository;
import cn.fancybull.framework.redis.RedisService;
import cn.fancybull.framework.repository.CommonRepository;
import javafx.collections.transformation.FilteredList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class FWMessageService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private CommonRepository commonRepository;
    @Resource
    private RedisService redis;
    @Resource
    private FWMessagedetailRepository fwMessagedetailRepository;
    @Resource
    private FWMessageRepository fwMessageRepository;
    @Autowired
    private FWMessageDAO fwMessageDAO;
    @Transactional
    public List<FwMessage>  selectMessage(String userid) {
        List<FwMessage> fwMessageList = fwMessageRepository.findByUserid(userid);
//        List<FWMessageDTO> fwMessageDTOList = new ArrayList<FWMessageDTO>(fwMessageList.size());
//        if(fwMessageList.size()!=0) {
//            for (int i = 0; i <= fwMessageList.size(); i++) {
//                fwMessageDTOList.get(i).setMessageid(fwMessageList.get(i).getMessageid());
//                fwMessageDTOList.get(i).setUserid(fwMessageList.get(i).getUserid());
//                fwMessageDTOList.get(i).setMessagetype(fwMessageList.get(i).getMessagetype());
//                fwMessageDTOList.get(i).setMessagetime(fwMessageList.get(i).getMessagetime());
//                fwMessageDTOList.get(i).setTitle(fwMessageList.get(i).getTitle());
//                fwMessageDTOList.get(i).setIfread(fwMessageList.get(i).getIfread());
//                fwMessageDTOList.get(i).setReadtime(fwMessageList.get(i).getReadtime());
//                fwMessageDTOList.get(i).setEventid(fwMessageList.get(i).getEventid());
//            }
//
//            for (int a = 0; a <= fwMessageList.size(); a++) {
//                List<FwMessagedetail> fwMessagedetails = fwMessagedetailRepository.findByMessageid(fwMessageList.get(a).getMessageid());
//                fwMessageDTOList.get(a).setFwMessagedetailList(fwMessagedetails);
//            }
//        }
        return fwMessageList;
    }

}
