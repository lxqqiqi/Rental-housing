package cn.fancybull.business.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "audit_fw_houseinfo", schema = "crebas", catalog = "")
public class AuditFwHouseinfo {
    private String autidid;
    private String houseinfoid;
    private String audituserid;

    @Id
    @Column(name = "autidid")
    public String getAutidid() {
        return autidid;
    }

    public void setAutidid(String autidid) {
        this.autidid = autidid;
    }

    @Basic
    @Column(name = "houseinfoid")
    public String getHouseinfoid() {
        return houseinfoid;
    }

    public void setHouseinfoid(String houseinfoid) {
        this.houseinfoid = houseinfoid;
    }

    @Basic
    @Column(name = "audituserid")
    public String getAudituserid() {
        return audituserid;
    }

    public void setAudituserid(String audituserid) {
        this.audituserid = audituserid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuditFwHouseinfo that = (AuditFwHouseinfo) o;
        return Objects.equals(autidid, that.autidid) &&
                Objects.equals(houseinfoid, that.houseinfoid) &&
                Objects.equals(audituserid, that.audituserid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(autidid, houseinfoid, audituserid);
    }
}
