package cn.fancybull.business.img.repository;

import cn.fancybull.business.entity.FwImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FWImgRepository extends JpaRepository<FwImg,String> {
}
