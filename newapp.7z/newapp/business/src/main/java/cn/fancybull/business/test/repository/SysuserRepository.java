package cn.fancybull.business.test.repository;

import cn.fancybull.business.test.entity.Sysuser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SysuserRepository extends JpaRepository<Sysuser, String> {
}
