package cn.fancybull.business.wx.dto;

import cn.fancybull.business.entity.FwUser;
import com.alibaba.fastjson.JSONObject;

public class ReturnWXDTO {
    private JSONObject wx;
    private String unionid;

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public JSONObject getWx() {
        return wx;
    }

    public void setWx(JSONObject wx) {
        this.wx = wx;
    }

    public String getWxtoken() {
        return wxtoken;
    }

    public void setWxtoken(String wxtoken) {
        this.wxtoken = wxtoken;
    }

    private String wxtoken;

    private String sm;//0未实名1实名

    public String getSm() {
        return sm;
    }

    public void setSm(String sm) {
        this.sm = sm;
    }

    public FwUser fwUser;

    public FwUser getFwUser() {
        return fwUser;
    }

    public void setFwUser(FwUser fwUser) {
        this.fwUser = fwUser;
    }
}
