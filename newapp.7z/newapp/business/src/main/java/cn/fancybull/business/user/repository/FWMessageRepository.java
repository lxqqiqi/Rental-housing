package cn.fancybull.business.user.repository;

import cn.fancybull.business.entity.FwMessage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FWMessageRepository extends JpaRepository<FwMessage,String> {
    List<FwMessage> findByUserid(String userid);
}
