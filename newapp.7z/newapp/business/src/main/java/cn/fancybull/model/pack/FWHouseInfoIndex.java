package cn.fancybull.model.pack;

public class FWHouseInfoIndex {
    private Integer lvfwczjs;//出租间数
    private String ifverify;//是否审核
    private String systemid;//标准地址编码
    private int taxinumber;//租客人数

    public Integer getLvfwczjs() {
        return lvfwczjs;
    }

    public void setLvfwczjs(Integer lvfwczjs) {
        this.lvfwczjs = lvfwczjs;
    }

    public String getIfverify() {
        return ifverify;
    }

    public void setIfverify(String ifverify) {
        this.ifverify = ifverify;
    }

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid;
    }

    public int getTaxinumber() {
        return taxinumber;
    }

    public void setTaxinumber(int taxinumber) {
        this.taxinumber = taxinumber;
    }
}
