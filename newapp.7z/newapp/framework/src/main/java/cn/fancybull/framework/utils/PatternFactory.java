package cn.fancybull.framework.utils;


import org.apache.commons.collections.FastHashMap;

import java.util.Map;
import java.util.regex.Pattern;

public class PatternFactory
{
  static Map patternMap = new FastHashMap();
  
  public static Pattern getPattern(String s)
  {
    Pattern pattern = null;
    if (patternMap.containsKey(s))
    {
      pattern = (Pattern)patternMap.get(s);
    }
    else
    {
      pattern = pattern = Pattern.compile(s);
      patternMap.put(s, pattern);
    }
    return pattern;
  }
}