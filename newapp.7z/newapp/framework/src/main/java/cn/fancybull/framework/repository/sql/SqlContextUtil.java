package cn.fancybull.framework.repository.sql;

import cn.fancybull.framework.utils.DataType;
import cn.fancybull.framework.utils.DateUtil;
import cn.fancybull.framework.utils.StringUtil;
import org.apache.commons.beanutils.PropertyUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SqlContextUtil {

	static String baseExp = "\\s*((in)|(like)|=|(>)|(<)|(>=)|(<=)|(!=))\\s*";
	static String prefix = ":";
	static String baseAnd = "\\s*(and)?\\s*";

	private static String getQueryString(String baseQueryString, Object form) throws Exception {
		String result = baseQueryString;
		if (form == null) {
			return baseQueryString;
		}
		List<Field> fieldList = new ArrayList<Field>() ;
		Class tempClass = form.getClass();
		while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
		      fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
		      tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
		}
		Field fields[] = new Field[fieldList.size()];
		for(int i = 0;i < fieldList.size() ;i++) {
			fields[i] = fieldList.get(i);
		}
		Field.setAccessible(fields, true);

		for (int i = 0; i < fields.length; i++) {

			String regExp = "((And)|(aNd)|(anD)|(ANd)|(aND)|(and)|(AND)|(or)|(OR)|(Or)|(oR))\\s*[(]?\\s*[\\S]+" + baseExp + "(['%']+\\s*[+]+\\s*)*"
					+ prefix + fields[i].getName() + "(\\s*[+]+\\s*['%']+)*" + "[)]?";
			try {
				if ((fields[i].get(form) == null) || ("".equals(fields[i].get(form)))) {
					Pattern p = Pattern.compile(regExp, 2);
					Matcher m = p.matcher(result);
					if (m.find()) {
						result = StringUtil.regexReplace(regExp, " ", result);
					} else if (fields[i].get(form) == null) {
						result = StringUtil.regexReplace(":" + fields[i].getName(), "null", result);
					} else {
						result = StringUtil.regexReplace(":" + fields[i].getName(), "''", result);
					}

				}

			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}
		boolean flag = true;
		while (flag) {
			if (result.trim().endsWith("and")) {
				result = result.substring(0, result.lastIndexOf("and"));
			} else {
				flag = false;
			}
		}
		flag = true;
		while (flag) {
			if (result.trim().endsWith("where")) {
				result = result.substring(0, result.lastIndexOf("where"));
			} else {
				flag = false;
			}
		}
		flag = true;
		while (flag) {
			if (result.trim().endsWith("or")) {
				result = result.substring(0, result.lastIndexOf("or"));
			} else {
				flag = false;
			}
		}
		return result;
	}

	private static String[] getParaValues(String queryString, Object form) throws Exception {
		List paraValues = new ArrayList();
		List<Field> fieldList = new ArrayList<Field>() ;
		Class tempClass = form.getClass();
		while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
		      fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
		      tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
		}
		Field fields[] = new Field[fieldList.size()];
		for(int i = 0;i < fieldList.size() ;i++) {
			fields[i] = fieldList.get(i);
		}
		Field.setAccessible(fields, true);

		for (int i = 0; i < fields.length; i++) {
			String paraName = fields[i].getName();
			try {
				if (fields[i].get(form) != null) {
					Object obj = PropertyUtils.getProperty(form, fields[i].getName());
					if (fields[i].getType().toString().contains(DataType.TYPE_STRING)) {
						String valStr = obj.toString();

						StringBuffer buff = new StringBuffer(valStr);

						String rightLike = "like\\s*:" + paraName + "(\\s*[+]+\\s*['%']+)+";
						String leftLike = "like\\s*(['%']+\\s*[+]+\\s*)+:" + paraName;
						String like = "like\\s*:" + paraName;
						String ins = "in\\s*:" + paraName;
						if (StringUtil.exist(ins, queryString)) {
							String inString = buff.toString().replaceAll("\\(", "\\('").replaceAll("\\)", "'\\)").replaceAll(",", "','");

							paraValues.add(inString);
						} else if (StringUtil.exist(rightLike, queryString)) {
							buff.insert(0, "'").append("%'");
							paraValues.add(buff.toString());
						} else if (StringUtil.exist(leftLike, queryString)) {
							buff.insert(0, "'%").append("'");
							paraValues.add(buff.toString());
						} else if (StringUtil.exist(like, queryString)) {
							buff.insert(0, "'%").append("%'");
							paraValues.add(buff.toString());
						} else {
							buff.insert(0, "'").append("'");
							paraValues.add(buff.toString());
						}
					} else if (fields[i].getType().toString().contains(DataType.TYPE_INTEGER)) {
						paraValues.add(obj.toString());
					} else if (fields[i].getType().toString().equals(DataType.TYPE_DATE)) {
						StringBuffer sb = new StringBuffer("to_date('");
						if ((obj instanceof java.sql.Date)) {
							sb.append(DateUtil.dateToString(new java.util.Date(((java.sql.Date) obj).getTime()), "YYYY-MM-DD"));
						} else if ((obj instanceof java.util.Date)) {
							sb.append(DateUtil.dateToString((java.util.Date) obj, "YYYY-MM-DD"));
						}
						sb.append("','YYYY-MM-DD')");
						paraValues.add(i, sb.toString());
					} else if (fields[i].getType().toString().equals(DataType.TYPE_BOOLEAN)) {
						paraValues.add(obj.toString());
					} else if (fields[i].getType().toString().equals(DataType.TYPE_BIG_DECIMAL)) {
						paraValues.add(obj.toString());
					} else {
						paraValues.add(obj.toString());
					}
				} else {
					paraValues.add(null);

				}
			} catch (NoSuchMethodException ex) {
				ex.printStackTrace();
				throw new Exception(ex);
			} catch (InvocationTargetException ex) {
				ex.printStackTrace();
				throw new Exception(ex);
			} catch (IllegalAccessException ex) {
				ex.printStackTrace();
				throw new Exception(ex);
			}
		}
		String[] result = new String[paraValues.size()];
		paraValues.toArray(result);
		// System.out.print(result[0]);
		return result;
	}

	private static String getQuerySQL(String queryString, Object form, String[] paraValues) throws Exception {
		String paraName = null;
		String paraValue = null;
		String result = queryString;
		String regExpBegin = "(['%']+\\s*[+]+\\s*)?:";
		String regExpEnd = "(\\s*[+]+\\s*['%']+)?";	//字段后面需要添加空格
		List<Field> fieldList = new ArrayList<Field>() ;
		Class tempClass = form.getClass();
		while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
		      fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
		      tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
		}
		Field paraNames[] = new Field[fieldList.size()];
		for(int i = 0;i < fieldList.size() ;i++) {
			paraNames[i] = fieldList.get(i);
		}
		//Field paraNames[] = form.getClass().getDeclaredFields();
		Field.setAccessible(paraNames, true);
		for (int i = 0; i < paraValues.length; i++) {
			paraName = paraNames[i].getName();
			paraValue = paraValues[i];
			try {
				if (paraValue != null)
					result = StringUtil.regexReplace(regExpBegin + paraName + regExpEnd, paraValue, result);
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new Exception(ex);
			}
		}
		return result;
	}

	public static synchronized String dealWithSql(String queryString, Object form) {
		if(null == form){
			return queryString;
		}
		String sqlparam;
		String[] paraValues;
		String hql = null;
		try {
			sqlparam = getQueryString(queryString, form);
			paraValues = getParaValues(sqlparam, form);
			hql = getQuerySQL(sqlparam, form, paraValues);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hql;

	}

}
