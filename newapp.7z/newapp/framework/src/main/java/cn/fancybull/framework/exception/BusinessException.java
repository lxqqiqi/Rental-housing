/**
 * 
 */
package cn.fancybull.framework.exception;

/**
 * @description 框架通过的异常类
 */
public class BusinessException extends RuntimeException {
	public BusinessException(String message) {
		super(message);
	}

	public BusinessException(Throwable cource) {
		super(cource);
	}

	public BusinessException(String message, Throwable cource) {
		super(message, cource);
	}

	public BusinessException() {
	}
}
