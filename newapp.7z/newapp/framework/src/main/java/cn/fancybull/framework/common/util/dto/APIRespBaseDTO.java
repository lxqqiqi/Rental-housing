package cn.fancybull.framework.common.util.dto;
import java.io.Serializable;

/**
 * API接口的基础数据传输类
 * @author zeroz
 *
 */
public class APIRespBaseDTO<T extends Object> implements Serializable {
    /**
     * 200 返回成功
     * <p>
     * 3xx 业务逻辑处理错误
     * （可自定义）
     * <p>
     * 4xx（请求错误）
     * 这些状态代码表示请求可能出错，妨碍了服务器的处理。
     * 代码	说明
     * 400   （错误请求） 服务器不理解请求的语法。
     * <p>
     * 403   （禁止） 服务器拒绝请求。
     * <p>
     * 408   （请求超时）  服务器等候请求时发生超时。
     * <p>
     * 413   （请求实体过大） 服务器无法处理请求，因为请求实体过大，超出服务器的处理能力。
     * <p>
     * 414   （请求的 URI 过长） 请求的 URI（通常为网址）过长，服务器无法处理。
     * <p>
     * <p>
     * 5xx（服务器错误）
     * 这些状态代码表示服务器在尝试处理请求时发生内部错误。 这些错误可能是服务器本身的错误，而不是请求出错。
     * <p>
     * 代码	说明
     * 500   （服务器内部错误）  服务器遇到错误，无法完成请求。
     * <p>
     * 503   （服务不可用） 服务器目前无法使用（由于超载或停机维护）。 通常，这只是暂时状态。
     */
    private Integer code;
    private String msg;

    private T result;

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getResult() {
        return result;
    }

    public void setResult(T result) {
        this.result = result;
    }
}
