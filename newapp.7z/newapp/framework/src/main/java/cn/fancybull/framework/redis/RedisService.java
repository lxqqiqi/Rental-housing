package cn.fancybull.framework.redis;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Service
public class RedisService {
    @Resource
    private StringRedisTemplate jedisTemplate;

    /**
     * 添加到队列
     */
    public Long pushToList(String key, String value) {
        return jedisTemplate.opsForList().leftPush(key, value);
    }
    /**
     * 从队列里取出
     */
    public String popFromList(String key) {
        return jedisTemplate.opsForList().rightPop(key);
    }

    /**
     * 字符串操作：新增或修改
     */
    public void putValue(String key, String value) {
        jedisTemplate.opsForValue().set(key, value);
    }

    /**
     * 字符串操作：新增或修改
     * @param key
     * @param value
     * @param time 有限时间，单位为秒
     */
    public void putValue(String key, String value, long time) {
        jedisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
    }

    /**
     * 字符串操作：取值
     */
    public String getValue(String key) {
        return jedisTemplate.opsForValue().get(key);
    }

    /**
     * 设置有效时间
     * @param key
     * @param time
     */
    public void expire(String key, long time){
        jedisTemplate.expire(key, time, TimeUnit.SECONDS);
    }

    /**
     * 删除key
     */
    public void remove(String key) {
        jedisTemplate.delete(key);
    }
}
