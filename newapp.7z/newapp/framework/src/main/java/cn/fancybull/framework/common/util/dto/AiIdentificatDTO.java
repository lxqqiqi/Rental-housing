package cn.fancybull.framework.common.util.dto;

public class AiIdentificatDTO {

    // 1身份证识别、2营业执照识别、3人脸比对、4驾驶证识别
    private String type;
    // 证件照
    private String img1;
    // 人像照
    private String img2;

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getImg1() {
        return img1;
    }
    public void setImg1(String img1) {
        this.img1 = img1;
    }
    public String getImg2() {
        return img2;
    }
    public void setImg2(String img2) {
        this.img2 = img2;
    }

}
