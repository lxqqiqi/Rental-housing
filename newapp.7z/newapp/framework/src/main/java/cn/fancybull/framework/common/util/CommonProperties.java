package cn.fancybull.framework.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
* @Author : XiangQian
* @Description
* @Date : 17:47 2017/11/25
*/
public class CommonProperties {
	private static Properties props;

    //初始化加载配置
    public static void initProp() throws IOException {
    	props = new Properties();
        InputStream inputStream = CommonProperties.class.getResourceAsStream("/common.properties");
        props.load(inputStream);
    }

    //根据KEY获取value
    public static String getValue(String key){
        String value = null;
        try {
        	if(null == props)
        		initProp();
            value = props.getProperty(key);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(null == value) value = "";
        return value;
    }
}
