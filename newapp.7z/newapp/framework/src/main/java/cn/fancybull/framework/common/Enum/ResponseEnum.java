package cn.fancybull.framework.common.Enum;

public enum ResponseEnum {

    RESPONSE_CODE_200(200,"请求成功"),
    RESPONSE_CODE_NO_DATA_200(200, "暂无数据"),
    /**
     * 首次登陆需修改密码
     */
    RESPONSE_CODE_201(201,"首次登陆需修改密码"),
    /**
     * 请求信息有误
     */
    RESPONSE_CODE_300(300,"请求信息有误"),
    /**
     * 无此用户或用户被锁定
     */
    RESPONSE_CODE_301(301,"无此用户或用户被锁定"),
    /**
     * 密码错误
     */
    RESPONSE_CODE_302(302,"密码错误"),
    /**
     * 用户没有所属的机构
     */
    RESPONSE_CODE_303(303,"用户没有所属的机构"),
    /**
     * 未登录或登录超时
     */
    RESPONSE_CODE_304(304,"未登录或登录超时"),
    /**
     * 未传入接口用户和密码
     */
    RESPONSE_CODE_305(305,"未传入接口用户和密码"),
    /**
     * 用户名/手机号码或密码为空
     */
    RESPONSE_CODE_306(306,"用户名/手机号码或密码为空"),
    /**
     * 存在多个有效账号，请先注销旧单位的账户
     */
    RESPONSE_CODE_307(307,"存在多个有效账号，请先注销旧单位的账户"),
    /**
     * 接口用户和密码校验失败
     */
    RESPONSE_CODE_308(308,"接口用户和密码校验失败"),
    /**
     * 接口需要路由，未传入userid或tel
     */
    RESPONSE_CODE_309(309,"接口需要路由，未传入userid或tel"),
    /**
     * 账号在其他设备终端登录，如不是本人操作，请重新登录后修改密码
     */
    RESPONSE_CODE_310(310,"账号在其他设备终端登录，如不是本人操作，请重新登录后修改密码"),
    /**
     * 未传入userid或usertoken
     */
    RESPONSE_CODE_311(311,"未传入userid或usertoken"),
    /**
     * 非法请求
     */
    RESPONSE_CODE_312(312,"非法请求"),
    
    /// 微信小程序或公众号请求的异常响应
    RESPONSE_CODE_330(330,"未传入openid 或 token或unionid"),
    RESPONSE_CODE_331(331,"用户未登录"),
    RESPONSE_CODE_332(332,"token错误"),
    
    RESPONSE_CODE_400(400,"服务器不理解请求的语法"),
    RESPONSE_CODE_403(403,"服务器拒绝请求"),
    RESPONSE_CODE_408(408,"服务器等候请求时发生超时"),
    RESPONSE_CODE_413(413,"服务器无法处理请求，因为请求实体过大，超出服务器的处理能力"),
    RESPONSE_CODE_414(414,"请求的 URI 过长"),
    RESPONSE_CODE_500 (500,"服务器遇到错误，无法完成请求"),
    RESPONSE_CODE_502 (503,"服务器目前无法使用（由于超载或停机维护）。 通常，这只是暂时状态"),
    RESPONSE_CODE_550 (550,"业务逻辑抛出异常"),
    RESPONSE_CODE_560 (560,"系统异常"),
	RESPONSE_CODE_570 (570,"自定义异常"),
	RESPONSE_CODE_0000 ("0000","公安网获取成功");

    private String name;
    private Integer code;
    private String value;
    // 构造方法
    private ResponseEnum(Integer code, String name) {
        this.name = name;
        this.code = code;
    }
    
    private ResponseEnum(String value, String name) {
        this.name = name;
        this.value = value;
    }
    
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static void main(String[] args) {
        System.out.println(ResponseEnum.RESPONSE_CODE_200.getCode()+":"+ResponseEnum.RESPONSE_CODE_200.getName()+":"+ResponseEnum.RESPONSE_CODE_200.getValue());
    }
}
