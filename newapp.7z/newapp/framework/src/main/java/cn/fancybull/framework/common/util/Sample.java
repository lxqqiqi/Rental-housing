package cn.fancybull.framework.common.util;
import java.util.UUID;

public class Sample {
    public static void main(String[] args) {
        System.out.println(UUID.randomUUID().toString().replace("-", ""));
    }
}
