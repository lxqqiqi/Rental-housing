package cn.fancybull.framework.repository.transformer;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.HibernateException;
import org.hibernate.transform.ResultTransformer;

import java.lang.reflect.Field;
import java.util.List;

/** 
 * @title: 将sql取到的值转为目标实例
 * @description: 
 * @version 1.0 
 */
public class SqlResultToBeanResultTransformer<T> implements ResultTransformer
{
	private Class<T> targetClass;

	/**
	 * 
	 */
	public SqlResultToBeanResultTransformer(Class<T> targetClass)
	{
		this.targetClass = targetClass;
	}

	@Override
	public Object transformTuple(Object[] fieldValues, String[] filedNames)
	{
		if (fieldValues == null || fieldValues.length == 0)
			return null;
		try
		{
			T targetBean = targetClass.newInstance();
			for (int i = 0; i < filedNames.length; i++)
			{
				String name = filedNames[i];
				Object value = fieldValues[i];
				if (value != null && !value.equals(""))
				{
					try
					{
						for (Class<?> superClass = targetClass; superClass != Object.class; superClass = superClass
								.getSuperclass())
						{
							Field[] fs = superClass.getDeclaredFields();
							for (Field f : fs)
							{
								if(name.toLowerCase().equals(f.getName().toLowerCase())) {
									BeanUtils.copyProperty(targetBean, f.getName(),
											value);
								}
							}
						}
					} catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			}
			return targetBean;
		} catch (InstantiationException e)
		{
			throw new HibernateException("Could not instantiate resultclass: "
					+ this.targetClass.getName());
		} catch (IllegalAccessException e)
		{
			throw new HibernateException("Could not instantiate resultclass: "
					+ this.targetClass.getName());
		}
	}

	@Override
	public List transformList(List paramList)
	{
		return paramList;
	}
}
