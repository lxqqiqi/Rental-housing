package cn.fancybull.framework.repository;

import cn.fancybull.framework.exception.BusinessException;
import cn.fancybull.framework.repository.sql.SqlContextUtil;
import cn.fancybull.framework.repository.transformer.AliasToEntityMapResultTransformer;
import cn.fancybull.framework.repository.transformer.SqlResultToBeanResultTransformer;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;
import java.util.List;


@Repository
public class CommonRepository{

    private final static int BATCH_SIZE = 1000;
    @PersistenceContext
    private EntityManager entityManager;

    public Session session() {
        return entityManager.unwrap(Session.class);
    }

    /**
     * 获取对象
     */
    public <T> T get(Class<T> clazz, Serializable id) {
        T object = (T) this.session().get(clazz, id);
        if(null != object){
            this.session().evict(object);
        }
        return object;
    }

    /**
     * 根据hql查询
     */
    public List retrieveObjs(String hql, Object[] objects) {
        Query query = this.session().createQuery(hql);
        query.setCacheable(true);
        if (objects != null) {
            for (int i = 0; i < objects.length; ++i)
                query.setParameter(i, objects[i]);
        }
        List list = query.list();
        for(Object obj : list) {
            this.session().evict(obj);
        }
        return list;
    }

    /**
     * 保存对象
     * @param entity
     * @return
     */
    public Object save(Object entity) {
        return session().save(entity);
    }

    /**
     * 保存List的所有对象
     */
    public void saveAll(List entitys) {
        for (int i = 0; i < entitys.size(); i++) {
            Object object = entitys.get(i);
            this.session().save(object);
            if (i % BATCH_SIZE == 0) {
                this.session().flush();
                this.session().clear();
            }
        }
        this.session().flush();
        this.session().clear();
    }

    /**
     * 删除对象
     */
    public void delete(Object object) {
        this.session().delete(object);
    }

    /**
     * 删除对象
     */
    public <T> void delete(Class<T> clazz, Serializable id) {
        T object = (T) this.session().load(clazz, id);
        this.session().delete(object);
    }

    /**
     * 删除HQL的查询结果
     * @param hql
     * @param objects
     * @return
     * 2016年2月25日 下午4:16:30
     */
    public void deleteAll(String hql, Object[] objects){
        List list = this.retrieveObjs(hql, objects);
        this.deleteAll(list);
    }

    /**
     * 删除List的所有对象
     */
    public void deleteAll(List entitys) {
        for (int i = 0; i < entitys.size(); i++) {
            this.session().delete(entitys.get(i));
            if (i % BATCH_SIZE == 0) {
                this.session().flush();
                this.session().clear();
            }
        }
        this.session().flush();
        this.session().clear();
    }

    /**
     * 更新对象
     */
    public void update(Object object) {
        this.session().update(object);
    }

    /**
     * 更新List所有对象
     */
    public void updateAll(List entitys) {
        for (int i = 0; i < entitys.size(); i++) {
            Object object = entitys.get(i);
            this.session().update(object);
            if (i % BATCH_SIZE == 0) {
                this.session().flush();
                this.session().clear();
            }
        }
        this.session().flush();
        this.session().clear();

    }

    /**
     * 根据sql语句查询
     * SQL字符串中带参数，参数形式为   :参数名   如:name
     *
     * @param sql
     *            sql语句
     * @param param sql语句的参数，是一个DTO对象
     * @param clazz
     *            返回对象的类型
     * @return 返回List对象
     */
    public List queryBySql(String sql, Object param, Class clazz){
        sql = SqlContextUtil.dealWithSql(sql, param);
        Query query = this.session().createSQLQuery(sql).setResultTransformer(new SqlResultToBeanResultTransformer(clazz));
        List results = query.list();
        return results;
    }

    /**
     * 根据sql语句查询
     * SQL字符串中带参数，参数形式为   :参数名   如:name
     *
      * @param sql sql语句
     * @param param sql语句的参数，是一个DTO对象
     * @return 返回List<Map></>对象
     */
    public List queryBySql(String sql, Object param) {
        sql = SqlContextUtil.dealWithSql(sql, param);
        Query query = this.session().createSQLQuery(sql).setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
        List results = query.list();
        return results;
    }

    /**
     * SQL语句，分页查询
     * @param sql SQL语句
     * @param param 参数DTO
     * @param clazz 返回的List对象
     * @param pagesize 每页记录数
     * @param pageno 请求页，从1开始
     * @return
     */
    public List queryForPages(String sql, Object param, Class clazz, Integer pagesize, Integer pageno) {
        if(pageno<1) {
            throw new BusinessException("请求页pageno，不能小于1");
        }
        if(pagesize<0 || pagesize > 200) {
            throw new BusinessException("每页记录数pagesize，范围为1-200");
        }
        sql = SqlContextUtil.dealWithSql(sql, param);
        Query query = this.session().createSQLQuery(sql).setResultTransformer(new SqlResultToBeanResultTransformer(clazz));
        List itemList = query.setFirstResult((pageno - 1) * pagesize).setMaxResults(pagesize).list();
        return itemList;
    }

    /**
     * HQL语句，分页查询
     * @param hql HQL语句
     * @param params 参数对象数组
     * @param pagesize 每页记录数
     * @param pageno 请求页，从1开始
     * @return
     */
    public List queryForPages(String hql, Object[] params, Integer pagesize, Integer pageno) {
        if(pageno<1) {
            throw new BusinessException("请求页pageno，不能小于1");
        }
        if(pagesize<0 || pagesize > 200) {
            throw new BusinessException("每页记录数pagesize，范围为1-200");
        }
        Query query = this.session().createQuery(hql);
        query.setCacheable(true);
        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                query.setParameter(i, params[i]);
            }
        }
        List itemList = query.setFirstResult((pageno - 1) * pagesize).setMaxResults( pagesize).list();
        for(Object obj : itemList) {
            this.session().evict(obj);
        }
        return itemList;
    }
}
