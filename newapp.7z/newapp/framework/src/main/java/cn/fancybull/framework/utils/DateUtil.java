package cn.fancybull.framework.utils;

import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 
 * @description 日期工具类
 */
public class DateUtil {
	public static int calBetweenTwoMonth(String s, String s1) {
		int i = 0;
		if ((s.length() != 6) || (s1.length() != 6)) {
			i = -1;
		} else {
			int j = Integer.parseInt(s);
			int k = Integer.parseInt(s1);
			if (j < k) {
				i = -2;
			} else {
				int l = Integer.parseInt(s.substring(0, 4));
				int i1 = Integer.parseInt(s.substring(4, 6));
				int j1 = Integer.parseInt(s1.substring(0, 4));
				int k1 = Integer.parseInt(s1.substring(4, 6));
				i = (l - j1) * 12 + i1 - k1;
			}
		}
		return i;
	}

	public static int convertDateToYear(Date date) {
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy", new DateFormatSymbols());
		return Integer.parseInt(simpledateformat.format(date));
	}

	/**
	 * 返回yyyyMM
	 * @param date
	 * @return
	 */
	public static String convertDateToYearMonth(Date date) {
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMM", new DateFormatSymbols());
		return simpledateformat.format(date);
	}

	public static String convertDateToYearMonthDay(Date date) {
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMMdd", new DateFormatSymbols());
		return simpledateformat.format(date);
	}

	public static String dateToString(Date date, String s) {
		if (date == null)
			return "";
		Hashtable hashtable = new Hashtable();
		String s1 = "";
		String s2 = s.toLowerCase();
		if (s2.indexOf("yyyy") != -1) {
			hashtable.put(new Integer(s2.indexOf("yyyy")), "yyyy");
		} else if (s2.indexOf("yy") != -1)
			hashtable.put(new Integer(s2.indexOf("yy")), "yy");
		if (s2.indexOf("mm") != -1)
			hashtable.put(new Integer(s2.indexOf("mm")), "MM");
		if (s2.indexOf("dd") != -1)
			hashtable.put(new Integer(s2.indexOf("dd")), "dd");
		if (s2.indexOf("hh24") != -1)
			hashtable.put(new Integer(s2.indexOf("hh24")), "HH");
		if (s2.indexOf("mi") != -1)
			hashtable.put(new Integer(s2.indexOf("mi")), "mm");
		if (s2.indexOf("ss") != -1)
			hashtable.put(new Integer(s2.indexOf("ss")), "ss");
		for (int i = 0; s2.indexOf("-", i) != -1; ++i) {
			i = s2.indexOf("-", i);
			hashtable.put(new Integer(i), "-");
		}

		for (int j = 0; s2.indexOf("/", j) != -1; ++j) {
			j = s2.indexOf("/", j);
			hashtable.put(new Integer(j), "/");
		}

		for (int k = 0; s2.indexOf(" ", k) != -1; ++k) {
			k = s2.indexOf(" ", k);
			hashtable.put(new Integer(k), " ");
		}

		for (int l = 0; s2.indexOf(":", l) != -1; ++l) {
			l = s2.indexOf(":", l);
			hashtable.put(new Integer(l), ":");
		}

		if (s2.indexOf("年") != -1)
			hashtable.put(new Integer(s2.indexOf("年")), "年");
		if (s2.indexOf("月") != -1)
			hashtable.put(new Integer(s2.indexOf("月")), "月");
		if (s2.indexOf("日") != -1)
			hashtable.put(new Integer(s2.indexOf("日")), "日");
		if (s2.indexOf("时") != -1)
			hashtable.put(new Integer(s2.indexOf("时")), "时");
		if (s2.indexOf("分") != -1)
			hashtable.put(new Integer(s2.indexOf("分")), "分");
		if (s2.indexOf("秒") != -1)
			hashtable.put(new Integer(s2.indexOf("秒")), "秒");
		boolean flag = false;
		while (hashtable.size() != 0) {
			Enumeration enumeration = hashtable.keys();
			int j1 = 0;
			while (enumeration.hasMoreElements()) {
				int i1 = ((Integer) enumeration.nextElement()).intValue();
				if (i1 >= j1)
					j1 = i1;
			}
			String s3 = (String) hashtable.get(new Integer(j1));
			hashtable.remove(new Integer(j1));
			s1 = s3 + s1;
		}
		SimpleDateFormat simpledateformat = new SimpleDateFormat(s1, new DateFormatSymbols());
		return simpledateformat.format(date);
	}

	public static int daysBetweenDates(Date date, Date date1) {
		int i = 0;
		Calendar calendar = Calendar.getInstance();
		Calendar calendar1 = Calendar.getInstance();
		calendar.setTime(date1);
		calendar1.setTime(date);
		int j = calendar.get(6);
		int k = calendar1.get(1);
		for (int l = calendar.get(1); k > l;) {
			calendar.set(2, 11);
			calendar.set(5, 31);
			i += calendar.get(6);
			++l;
			calendar.set(1, l);
		}

		int i1 = calendar1.get(6);
		i = i + i1 - j;
		return i;
	}

	public static String descreaseYearMonth(String s) {
		int i = new Integer(s.substring(0, 4)).intValue();
		int j = new Integer(s.substring(4, 6)).intValue();
		if (--j >= 10)
			return s.substring(0, 4) + new Integer(j).toString();
		if ((j > 0) && (j < 10)) {
			return s.substring(0, 4) + "0" + new Integer(j).toString();
		}
		return new Integer(i - 1).toString() + new Integer(j + 12).toString();
	}

	public static String getAddIssue(String s, int i) {
		String s1 = s;
		int j = i;
		int k = Integer.parseInt(s1) / 100;
		int l = Integer.parseInt(s1) % 100;
		int i1 = j / 12;
		int j1 = j % 12;
		k += i1;
		l += j1;
		if (l > 12) {
			++k;
			l -= 12;
		}
		if (l < 0) {
			--k;
			l += 12;
		}
		if (l < 10)
			s1 = Integer.toString(k).trim() + '0' + Integer.toString(l).trim();
		else
			s1 = Integer.toString(k).trim() + Integer.toString(l).trim();
		return s1;
	}

	public static int getAge(Date date, Date date1) throws Exception {
		String s = getStrDate(date);
		String s1 = getStrDate(date1);
		int i = getIntervalMonth(s, s1);
		int j = i / 12;
		if (i % 12 == 0) {
			String s2 = s.substring(6);
			String s3 = s1.substring(6);
			if (s2.compareTo(s3) > 0)
				--j;
		}
		return j;
	}

	public static int getAge(String s) throws Exception {
		int i = -1;
		int j = s.length();
		String s1 = "";
		if (j == 15) {
			s1 = s.substring(6, 8);
			s1 = "19" + s1;
		} else if (j == 18) {
			s1 = s.substring(6, 10);
		} else {
			throw new Exception("错误的身份证号");
		}
		int k = Calendar.getInstance().get(1);
		i = k - new Integer(s1).intValue();
		return i;
	}

	public static String getBirtday(String s) throws Exception {
		String s1 = "";
		int i = s.length();
		String s3 = "";
		int j = 0;
		String s4 = "";
		int k = 0;
		String s5 = "";
		int l = 0;
		boolean flag = false;
		String s6 = dateToString(new Date(), "yyyy-mm-dd");
		if (i == 15) {
			s3 = "19" + s.substring(6, 8);
			s4 = s.substring(8, 10);
			s5 = s.substring(10, 12);
		} else if (i == 18) {
			s3 = s.substring(6, 10);
			s4 = s.substring(10, 12);
			s5 = s.substring(12, 14);
		} else {
			return dateToString(new Date(), "yyyy-mm-dd");
		}
		j = new Integer(s3).intValue();
		k = new Integer(s4).intValue();
		l = new Integer(s5).intValue();
		if ((j < 1900) || (j > 2200))
			return s6;
		if ((j % 4 != 0) && (j % 100 != 0))
			flag = false;
		else
			flag = true;
		if (k == 2)
			if (flag) {
				if ((l < 1) || (l > 29))
					return s6;
			} else if ((l < 1) || (l > 28))
				return s6;
		if ((((k == 1) || (k == 3) || (k == 5) || (k == 7) || (k == 8) || (k == 10) || (k == 12)))
				&& (((l < 1) || (l > 31))))
			return s6;
		if ((((k == 4) || (k == 6) || (k == 9) || (k == 11))) && (((l < 1) || (l > 30)))) {
			return s6;
		}

		String s2 = s3 + "-" + s4 + "-" + s5;
		return s2;
	}

	public static String getChineseDate(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMMdd", new DateFormatSymbols());
		String s = simpledateformat.format(date);
		return s.substring(0, 4) + "年" + Integer.parseInt(s.substring(4, 6)) + "月" + Integer.parseInt(s.substring(6, 8))
				+ "日";
	}

	public static Date getCurrentDate() {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		return date;
	}

	/**
	 * 获取现在时间
	 * 
	 * @return返回长时间格式 yyyy-MM-dd HH:mm:ss
	 */
	public static Date getFullDateTime() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(currentTime);
		Date parse = null;
		try {
			parse = formatter.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return parse;
	}

	/**
	 * 获取现在时间
	 * 
	 * @return 返回短时间字符串格式yyyyMMdd
	 */
	public static String getShortStringDate() {
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		String dateString = formatter.format(currentTime);
		return dateString;
	}

	public static String getCurrentDate_String() {
		Calendar calendar = Calendar.getInstance();
		String s = null;
		String s1 = new Integer(calendar.get(1)).toString();
		String s2 = null;
		String s3 = null;
		if (calendar.get(2) < 9)
			s2 = "0" + new Integer(calendar.get(2) + 1).toString();
		else
			s2 = new Integer(calendar.get(2) + 1).toString();
		if (calendar.get(5) < 10)
			s3 = "0" + new Integer(calendar.get(5)).toString();
		else
			s3 = new Integer(calendar.get(5)).toString();
		s = s1 + s2 + s3;
		return s;
	}

	public static String getCurrentDate_String(String s) {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		return getDate(date, s);
	}

	public static int getCurrentYear() {
		Calendar calendar = Calendar.getInstance();
		int i = calendar.get(1);
		return i;
	}

	public static String getCurrentYearMonth() {
		Calendar calendar = Calendar.getInstance();
		String s = new Integer(calendar.get(1)).toString();
		String s1 = null;
		if (calendar.get(2) < 9)
			s1 = "0" + new Integer(calendar.get(2) + 1).toString();
		else
			s1 = new Integer(calendar.get(2) + 1).toString();
		return s + s1;
	}

	public static int getCurYearMonth() {
		Date date = new Date(System.currentTimeMillis());
		return getYearMonth(date);
	}

	public static java.sql.Date getDate() {
		return new java.sql.Date(System.currentTimeMillis());
	}

	public static java.sql.Date getSqlDate(int i, int j, int k) {
		return new java.sql.Date(new GregorianCalendar(i, j, k).getTimeInMillis());
	}

	public static Date getUtilDate(int i, int j, int k) {
		return new GregorianCalendar(i, j, k).getTime();
	}

	public static String getDate(Date date, String s) {
		if (date == null)
			return "";
		Hashtable hashtable = new Hashtable();
		String s1 = "";
		String s2 = s.toLowerCase();
		if (s2.indexOf("yyyy") != -1) {
			hashtable.put(new Integer(s2.indexOf("yyyy")), "yyyy");
		} else if (s2.indexOf("yy") != -1)
			hashtable.put(new Integer(s2.indexOf("yy")), "yy");
		if (s2.indexOf("mm") != -1)
			hashtable.put(new Integer(s2.indexOf("mm")), "MM");
		if (s2.indexOf("dd") != -1)
			hashtable.put(new Integer(s2.indexOf("dd")), "dd");
		if (s2.indexOf("hh24") != -1)
			hashtable.put(new Integer(s2.indexOf("hh24")), "HH");
		if (s2.indexOf("mi") != -1)
			hashtable.put(new Integer(s2.indexOf("mi")), "mm");
		if (s2.indexOf("ss") != -1)
			hashtable.put(new Integer(s2.indexOf("ss")), "ss");
		for (int i = 0; s2.indexOf("-", i) != -1; ++i) {
			i = s2.indexOf("-", i);
			hashtable.put(new Integer(i), "-");
		}

		for (int j = 0; s2.indexOf("/", j) != -1; ++j) {
			j = s2.indexOf("/", j);
			hashtable.put(new Integer(j), "/");
		}

		for (int k = 0; s2.indexOf(" ", k) != -1; ++k) {
			k = s2.indexOf(" ", k);
			hashtable.put(new Integer(k), " ");
		}

		for (int l = 0; s2.indexOf(":", l) != -1; ++l) {
			l = s2.indexOf(":", l);
			hashtable.put(new Integer(l), ":");
		}

		if (s2.indexOf("年") != -1)
			hashtable.put(new Integer(s2.indexOf("年")), "年");
		if (s2.indexOf("月") != -1)
			hashtable.put(new Integer(s2.indexOf("月")), "月");
		if (s2.indexOf("日") != -1)
			hashtable.put(new Integer(s2.indexOf("日")), "日");
		if (s2.indexOf("时") != -1)
			hashtable.put(new Integer(s2.indexOf("时")), "时");
		if (s2.indexOf("分") != -1)
			hashtable.put(new Integer(s2.indexOf("分")), "分");
		if (s2.indexOf("秒") != -1)
			hashtable.put(new Integer(s2.indexOf("秒")), "秒");
		boolean flag = false;
		while (hashtable.size() != 0) {
			Enumeration enumeration = hashtable.keys();
			int j1 = 0;
			while (enumeration.hasMoreElements()) {
				int i1 = ((Integer) enumeration.nextElement()).intValue();
				if (i1 >= j1)
					j1 = i1;
			}
			String s3 = (String) hashtable.get(new Integer(j1));
			hashtable.remove(new Integer(j1));
			s1 = s3 + s1;
		}
		SimpleDateFormat simpledateformat = new SimpleDateFormat(s1, new DateFormatSymbols());
		return simpledateformat.format(date);
	}

	public static Date getDateBetween(Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(5, i);
		return calendar.getTime();
	}

	public static String getDateBetween_String(Date date, int i, String s) {
		Date date1 = getDateBetween(date, i);
		return getDate(date1, s);
	}

	public static java.sql.Date getDateByAge(int i) {
		Calendar calendar = Calendar.getInstance(Locale.CHINESE);
		calendar.set(calendar.get(1) - i, calendar.get(2), calendar.get(5));
		return new java.sql.Date(calendar.getTimeInMillis());
	}

	public static String getFirstDayOfNextMonth() {
		String s = getCurrentDate_String();
		return increaseYearMonth(s.substring(0, 6)) + "01";
	}

	public static String getGender(String s) {
		int i = 3;
		if (s.length() == 15) {
			i = new Integer(s.substring(14, 15)).intValue() % 2;
		} else if (s.length() == 18) {
			int j = new Integer(s.substring(16, 17)).intValue();
			i = j % 2;
		}
		if (i == 1)
			return "1";
		if (i == 0) {
			return "2";
		}
		return "";
	}

	public static int getIntervalDay(java.sql.Date date, java.sql.Date date1) {
		long l = date.getTime();
		long l1 = date1.getTime();
		long l2 = l1 - l;
		int i = (int) l2 / 86400000;
		return i;
	}

	public static int getIntervalMonth(String s, String s1) {
		int i = Integer.parseInt(s.substring(0, 4));
		int j = 0;
		if (s.substring(4, 5).equals("0"))
			j = Integer.parseInt(s.substring(5));
		j = Integer.parseInt(s.substring(4, 6));
		int k = Integer.parseInt(s1.substring(0, 4));
		int l = 0;
		if (s1.substring(4, 5).equals("0"))
			l = Integer.parseInt(s1.substring(5));
		l = Integer.parseInt(s1.substring(4, 6));
		int i1 = k * 12 + l - (i * 12 + j);
		return i1;
	}

	public static String getLastDay(String s) {
		int i = Integer.parseInt(s.substring(0, 4));
		int j = Integer.parseInt(s.substring(4, 6));
		String s1 = "";
		if (j == 2) {
			if (((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0))
				s1 = "29";
			else
				s1 = "28";
		} else if ((j == 4) || (j == 6) || (j == 9) || (j == 11))
			s1 = "30";
		else
			s1 = "31";
		return String.valueOf(i) + "年" + String.valueOf(j) + "月" + s1 + "日";
	}

	public static String getMonthBetween(String s, String s1) {
		try {
			String s2;
			if ((s.equals("")) || (s1.equals("")) || (s.length() != 6) || (s1.length() != 6)) {
				s2 = "";
			} else {
				int i = Integer.parseInt(s.substring(0, 4)) * 12 + Integer.parseInt(s.substring(4, 6));
				int j = Integer.parseInt(s1.substring(0, 4)) * 12 + Integer.parseInt(s1.substring(4, 6));
				s2 = String.valueOf(i - j);
			}
			return s2;
		} catch (Exception _ex) {
		}
		return "0";
	}

	public static String getOracleFormatDateStr(Date date) {
		return getDate(date, "YYYY-MM-DD HH24:MI:SS");
	}

	public static java.sql.Date getStepDay(java.sql.Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(6, i);
		return new java.sql.Date(calendar.getTime().getTime());
	}

	public static java.sql.Date getStepMonth(Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(2, i);
		return new java.sql.Date(calendar.getTime().getTime());
	}

	public static java.sql.Date getStepYear(Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(1, i);
		return new java.sql.Date(calendar.getTime().getTime());
	}

	public static String getStrDate(Date date) throws Exception {
		Date date1 = date;
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.setTime(date1);
		int i = calendar.get(1);
		if ((i < 1000) || (i > 9999))
			throw new Exception("错误的年！");
		int j = calendar.get(2) + 1;
		String s = "" + j;
		if (j < 10)
			s = "0" + j;
		int k = calendar.get(5);
		String s1 = "" + k;
		if (k < 10)
			s1 = "0" + k;
		return i + s + s1;
	}

	public static String getStrHaveAcross(String s) {
		try {
			return s.substring(0, 4) + "-" + s.substring(4, 6) + "-" + s.substring(6, 8);
		} catch (Exception _ex) {
		}
		return s;
	}

	public static String getYearAndMonth(String s) {
		if (s == null)
			return "";
		String s1 = s.trim();
		if (6 != s1.length()) {
			return s1;
		}

		String s2 = s1.substring(0, 4);
		String s3 = s1.substring(4);
		return s2 + "年" + s3 + "月";
	}

	public static String getYearMonth(java.sql.Date date) {
		if (date == null) {
			return null;
		}

		String s = date.toString();
		return s.substring(0, 4) + "-" + s.substring(5, 7);
	}

	public static int getYearMonth(Date date) {
		GregorianCalendar gregoriancalendar = new GregorianCalendar();
		gregoriancalendar.setTime(date);
		return (gregoriancalendar.get(1) * 100 + gregoriancalendar.get(2));
	}

	public static String getYearMonthByMonth(String s) {
		if (s == null)
			return null;
		String s1 = s.trim();
		if (6 != s1.length()) {
			return s1;
		}

		String s2 = s1.substring(0, 4);
		return s2 + "年" + s + "月";
	}

	public static String getYearMonthReduceOneMonth(java.sql.Date date) {
		if (date == null) {
			return null;
		}

		String s = date.toString();
		String s1 = s.substring(0, 4) + s.substring(5, 7);
		s1 = descreaseYearMonth(s1);
		return s1.substring(0, 4) + "-" + s1.substring(4, 6);
	}

	public static Date increaseMonth(Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(2, i);
		return calendar.getTime();
	}

	public static Date increaseYear(Date date, int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(1, i);
		return calendar.getTime();
	}

	public static String increaseYearMonth(String s) {
		int i = new Integer(s.substring(0, 4)).intValue();
		int j = new Integer(s.substring(4, 6)).intValue();
		if ((++j <= 12) && (j >= 10))
			return s.substring(0, 4) + new Integer(j).toString();
		if (j < 10) {
			return s.substring(0, 4) + "0" + new Integer(j).toString();
		}
		return new Integer(i + 1).toString() + "0" + new Integer(j - 12).toString();
	}

	public static String increaseYearMonth(String s, int i) {
		int j = new Integer(s.substring(0, 4)).intValue();
		int k = new Integer(s.substring(4, 6)).intValue();
		k += i;
		j += k / 12;
		k %= 12;
		if ((k <= 12) && (k >= 10)) {
			return j + new Integer(k).toString();
		}
		return j + "0" + new Integer(k).toString();
	}

	public static String month2YearMonth(String s) {
		String s1 = "";
		int i = 0;
		int j = 0;
		int k = 0;
		if ((s == null) || ("0".equals(s)) || ("".equals(s.trim())))
			return "0月";
		i = Integer.parseInt(s);
		j = i / 12;
		k = i % 12;
		if (j > 0)
			s1 = j + "年";
		if (k > 0)
			s1 = s1 + k + "个月";
		return s1;
	}

	public static synchronized java.sql.Date stringToDate(String s) {
		SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = simpledateformat.parse(s, new ParsePosition(0));
		return new java.sql.Date(date.getTime());
	}

	public static Date stringToDate(String s, String s1) {
		if (s == null)
			return null;
		Hashtable hashtable = new Hashtable();
		String s2 = "";
		String s3 = s1.toLowerCase();
		if (s3.indexOf("yyyy") != -1) {
			hashtable.put(new Integer(s3.indexOf("yyyy")), "yyyy");
		} else if (s3.indexOf("yy") != -1)
			hashtable.put(new Integer(s3.indexOf("yy")), "yy");
		if (s3.indexOf("mm") != -1)
			hashtable.put(new Integer(s3.indexOf("mm")), "MM");
		if (s3.indexOf("dd") != -1)
			hashtable.put(new Integer(s3.indexOf("dd")), "dd");
		if (s3.indexOf("hh24") != -1)
			hashtable.put(new Integer(s3.indexOf("hh24")), "HH");
		if (s3.indexOf("mi") != -1)
			hashtable.put(new Integer(s3.indexOf("mi")), "mm");
		if (s3.indexOf("ss") != -1)
			hashtable.put(new Integer(s3.indexOf("ss")), "ss");
		for (int i = 0; s3.indexOf("-", i) != -1; ++i) {
			i = s3.indexOf("-", i);
			hashtable.put(new Integer(i), "-");
		}

		for (int j = 0; s3.indexOf("/", j) != -1; ++j) {
			j = s3.indexOf("/", j);
			hashtable.put(new Integer(j), "/");
		}

		for (int k = 0; s3.indexOf(" ", k) != -1; ++k) {
			k = s3.indexOf(" ", k);
			hashtable.put(new Integer(k), " ");
		}

		for (int l = 0; s3.indexOf(":", l) != -1; ++l) {
			l = s3.indexOf(":", l);
			hashtable.put(new Integer(l), ":");
		}

		if (s3.indexOf("年") != -1)
			hashtable.put(new Integer(s3.indexOf("年")), "年");
		if (s3.indexOf("月") != -1)
			hashtable.put(new Integer(s3.indexOf("月")), "月");
		if (s3.indexOf("日") != -1)
			hashtable.put(new Integer(s3.indexOf("日")), "日");
		if (s3.indexOf("时") != -1)
			hashtable.put(new Integer(s3.indexOf("时")), "时");
		if (s3.indexOf("分") != -1)
			hashtable.put(new Integer(s3.indexOf("分")), "分");
		if (s3.indexOf("秒") != -1)
			hashtable.put(new Integer(s3.indexOf("秒")), "秒");
		boolean flag = false;
		while (hashtable.size() != 0) {
			Enumeration enumeration = hashtable.keys();
			int j1 = 0;
			while (enumeration.hasMoreElements()) {
				int i1 = ((Integer) enumeration.nextElement()).intValue();
				if (i1 >= j1)
					j1 = i1;
			}
			String s4 = (String) hashtable.get(new Integer(j1));
			hashtable.remove(new Integer(j1));
			s2 = s4 + s2;
		}
		SimpleDateFormat simpledateformat = new SimpleDateFormat(s2);
		Date date;
		try {
			date = simpledateformat.parse(s);
		} catch (Exception _ex) {
			return null;
		}
		return date;
	}

	public static Integer stringToNum(String s) {
		if ((s == null) || ("".equals(s))) {
			return null;
		}

		String s1 = s.replaceAll("-", "");
		Integer integer = new Integer(Integer.parseInt(s1));
		return integer;
	}

	public static java.sql.Date stringToSqlDate(String s, String s1) {
		Date date = stringToDate(s, s1);
		return new java.sql.Date(date.getTime());
	}

	public static boolean verityDate(int i, int j, int k) {
		boolean flag = false;
		if ((j >= 1) && (j <= 12) && (k >= 1) && (k <= 31)) {
			if ((j == 4) || (j == 6) || (j == 9) || (j == 11)) {
				if (k <= 30)
					flag = true;
			} else if (j == 2) {
				if (((i % 100 != 0) && (i % 4 == 0)) || (i % 400 == 0)) {
					if (k <= 29)
						flag = true;
				} else if (k <= 28)
					flag = true;
			} else
				flag = true;
		}
		return flag;
	}

	public static boolean yearMonthGreatEqual(String s, String s1) {
		String s2 = s.substring(0, 4);
		String s3 = s1.substring(0, 4);
		String s4 = s.substring(4, 6);
		String s5 = s1.substring(4, 6);
		if (Integer.parseInt(s2) > Integer.parseInt(s3))
			return true;
		if (Integer.parseInt(s2) == Integer.parseInt(s3)) {
			return (Integer.parseInt(s4) >= Integer.parseInt(s5));
		}
		return false;
	}

	public static boolean yearMonthGreater(String s, String s1) {
		String s2 = s.substring(0, 4);
		String s3 = s1.substring(0, 4);
		String s4 = s.substring(4, 6);
		String s5 = s1.substring(4, 6);
		if (Integer.parseInt(s2) > Integer.parseInt(s3))
			return true;
		if (Integer.parseInt(s2) == Integer.parseInt(s3)) {
			return (Integer.parseInt(s4) > Integer.parseInt(s5));
		}
		return false;
	}

	/**
	 * 将日期转换为毫秒数
	 */
	public static Long toMillis(String dateTime) {
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateTime));
			return calendar.getTimeInMillis();
		} catch (Exception e) {
			return 0l;
		}

	}

	/**
	 * 将毫秒数转为日期
	 */
	public static Date millisTODate(Long millis) {
		return new Date(millis);
	}

	/**
	 * 将毫秒数转为日期
	 */
	public static String millisTOString(Long millis) {
		SimpleDateFormat simp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date(millis);
		return simp.format(date);
	}

	public static Date stringToDates(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟
		try {
			return sdf.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// 获取最近一小时时间
	public static String getTimeHour() {
		Calendar calen = Calendar.getInstance();// 可以对每个时间域单独修改
		calen.setTime(new Date());
		calen.set(Calendar.HOUR_OF_DAY, calen.get(Calendar.HOUR_OF_DAY) - 1);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = format.format(calen.getTime());
		return time;
	}

	// 获取前半个小时时间
	public static String getTimeHalfHour() {
		long curren = System.currentTimeMillis();
		curren -= 30 * 60 * 1000;
		Date da = new Date(curren);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = dateFormat.format(da);
		return time;
	}

	// 获取当前时间
	public static String getTime() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = dateFormat.format(new Date());
		return time;
	}
	
	//获取前一天的时间
	public static String getTimeYear(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        Date date=new Date();  
        Calendar calendar = Calendar.getInstance();  
        calendar.setTime(date);  
        calendar.add(Calendar.DAY_OF_MONTH, -1);  
        date = calendar.getTime(); 
        return sdf.format(date);
	}
	
	//获取前一天的时间
	public static String getTimeYearType(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");  
        Date date=new Date();  
        Calendar calendar = Calendar.getInstance();  
        calendar.setTime(date);  
        calendar.add(Calendar.DAY_OF_MONTH, -1);  
        date = calendar.getTime(); 
        return sdf.format(date);
	}
}