package cn.fancybull.framework.common.util;

import cn.fancybull.framework.common.Enum.ResponseEnum;
import cn.fancybull.framework.common.util.dto.APIRespBaseDTO;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

public class AliSmsUtil {

    public static APIRespBaseDTO<Object> getSmsCode(String strPhone, String strPhoneCode, String apptype) {
        APIRespBaseDTO<Object> res = new APIRespBaseDTO<Object>();
        try {
            // 设置超时时间
            System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
            System.setProperty("sun.net.client.defaultReadTimeout", "10000");
            // 初始化ascClient需要的几个参数
            final String product = "Dysmsapi"; // 短信API产品名称
            final String domain = "dysmsapi.aliyuncs.com"; // 短信API产品域名
            final String accessKeyId = CommonProperties.getValue("aliyun_sms_accessKeyId");
            final String accessKeySecret = CommonProperties.getValue("aliyun_sms_accessKeySecret");
            // 初始化ascClient
            IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
            DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
            IAcsClient acsClient = new DefaultAcsClient(profile);

            // 组装请求对象
            SendSmsRequest request = new SendSmsRequest();
            // 使用post提交
            request.setMethod(MethodType.POST);
            // 待发送手机号
            request.setPhoneNumbers(strPhone);
            // 短信签名
            if ("3".equals(apptype)) {
                request.setSignName("智采通");
            } else if ("4".equals(apptype)) {
                request.setSignName("E采集");
            } else {
                request.setSignName("五色神牛");
            }

            // 短信模板
            if ("3".equals(apptype) || "4".equals(apptype)) {
                request.setTemplateCode(CommonProperties.getValue("aliyun_sms_templateCode_E"));
            } else {
                request.setTemplateCode(CommonProperties.getValue("aliyun_sms_templateCode"));
            }
            request.setTemplateParam("{\"code\":\"" + strPhoneCode + "\"}");
            SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                res.setResult(strPhoneCode);
                res.setCode(ResponseEnum.RESPONSE_CODE_200.getCode());
                res.setMsg("验证码已发送");
            } else {
                res.setCode(ResponseEnum.RESPONSE_CODE_570.getCode());
                res.setMsg(sendSmsResponse.getMessage());
            }
        } catch (ClientException e) {
            e.printStackTrace();
            res.setCode(ResponseEnum.RESPONSE_CODE_570.getCode());
            res.setMsg("获取验证码失败");
        }

        return res;
    }
}
