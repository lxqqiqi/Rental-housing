package cn.fancybull.framework.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataType
{
  public static String TYPE_STRING = "String";
  public static String TYPE_DOUBLE = "Double";
  public static String TYPE_INTEGER = "Integer";
  public static String TYPE_DATE = "Date";
  public static String TYPE_BOOLEAN = "Boolean";
  public static String TYPE_BIG_DECIMAL = "Bigdecimal";
  private static Map descs = new HashMap();
  private String name;
  
  static
  {
    descs.put(TYPE_STRING, "字符串");
    descs.put(TYPE_DOUBLE, "浮点小数");
    descs.put(TYPE_INTEGER, "整型");
    descs.put(TYPE_DATE, "日期");
    descs.put(TYPE_BOOLEAN, "布尔");
    descs.put(TYPE_BIG_DECIMAL, "大数值");
  }
  
  public static String getTypeTitle(String type)
  {
    return (String)descs.get(type);
  }
  
  public static List<DataType> getTypes()
  {
    List<DataType> res = new ArrayList();
    try
    {
      DataType type = (DataType) DataType.class.newInstance();
      
      Field[] fields = DataType.class.getFields();
      for (int i = 0; i < fields.length; i++)
      {
        String name = fields[i].getName();
        String val = (String)fields[i].get(type);
        if (name.indexOf("TYPE_") >= 0)
        {
          DataType t = new DataType();
          t.setName(val);
          
          res.add(t);
        }
      }
    }
    catch (InstantiationException e)
    {
      e.printStackTrace();
    }
    catch (IllegalAccessException e)
    {
      e.printStackTrace();
    }
    return res;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public String getTitle()
  {
    return getTypeTitle(this.name);
  }
}

